"""
editor/ffmpeg_editor.py - FFmpeg 视频剪辑适配器
通过调用 ffmpeg / ffprobe 命令实现视频剪辑、拼接、混流、字幕烧录。
依赖: ffmpeg + ffprobe (需提前安装)
"""
import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from .base import (
    AudioTrack,
    EditPlan,
    EditResult,
    EditorProvider,
    SubtitleOverlay,
    VideoClip,
)


class FFmpegEditorProvider(EditorProvider):
    """FFmpeg 视频剪辑适配器"""

    name = "ffmpeg"

    def __init__(self, ffmpeg_path: str = "ffmpeg", ffprobe_path: str = "ffprobe"):
        self.ffmpeg = shutil.which(ffmpeg_path) or ffmpeg_path
        self.ffprobe = shutil.which(ffprobe_path) or ffprobe_path

    def _run(self, cmd: list, check: bool = True, capture: bool = False) -> subprocess.CompletedProcess:
        """执行命令"""
        return subprocess.run(
            cmd,
            check=check,
            capture_output=capture,
            text=True,
        )

    def _get_duration_ms(self, path: Path) -> int:
        """用 ffprobe 获取视频时长（毫秒）"""
        cmd = [
            self.ffprobe,
            "-v", "quiet",
            "-print_format", "json",
            "-show_format", str(path),
        ]
        result = self._run(cmd, capture=True)
        data = json.loads(result.stdout)
        duration = float(data["format"]["duration"])
        return int(duration * 1000)

    def _build_video_filter(self, clips: list[VideoClip], plan: EditPlan) -> str:
        """构建 FFmpeg video filter 字符串"""
        filters = []
        # 缩放到目标分辨率
        filters.append(
            f"scale={plan.output_width}:{plan.output_height}:force_original_aspect_ratio=decrease,"
            f"pad={plan.output_width}:{plan.output_height}:(ow-iw)/2:(oh-ih)/2,"
            f"fps={plan.output_fps}"
        )
        return ";".join(filters)

    def _temp_file(self, suffix: str) -> Path:
        import tempfile
        return Path(tempfile.mktemp(suffix=suffix))

    def assemble(
        self,
        plan: EditPlan,
        output_path: Path,
        *,
        progress_callback: Optional[callable] = None,
    ) -> EditResult:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if not plan.clips:
            raise ValueError("EditPlan 至少需要一个 VideoClip")

        # 1. 计算每个 clip 的实际时长
        clip_files: list[Path] = []
        for clip in plan.clips:
            clip_file = clip.path
            if not clip_file.exists():
                raise FileNotFoundError(f"视频文件不存在: {clip_file}")
            clip_files.append(clip_file)

        # 2. 准备滤镜
        video_filter = self._build_video_filter(plan.clips, plan)

        # 3. 构建输入参数
        input_args: list[str] = []
        for clip in plan.clips:
            input_args += ["-i", str(clip.path)]

        # 4. 构建音频混合 FilterComplex
        audio_inputs = ""
        audio_filters = []
        for i, track in enumerate(plan.audio_tracks):
            audio_inputs += f" -i {track.path}"
            # 延迟 + 音量
            delay_ms = track.start_ms
            volume = track.volume
            audio_filters.append(
                f"[{i}:a]adelay={delay_ms}|{delay_ms},volume={volume}[a{i}]"
            )

        if audio_filters:
            audio_filter_complex = ";".join(audio_filters) + ";" + \
                "".join(f"[a{i}]" for i in range(len(plan.audio_tracks))) + \
                f"amix=inputs={len(plan.audio_tracks)}:duration=longest[outa]"
        else:
            audio_filter_complex = ""

        # 5. 字幕烧录
        subtitle_filter = ""
        if plan.subtitle_overlay:
            sub_path = plan.subtitle_overlay.srt_path
            subtitle_filter = (
                f",ass={sub_path}"
            )

        # 6. 组合最终 filter
        final_video_filter = video_filter + subtitle_filter

        # 7. 构建 ffmpeg 命令
        cmd = [self.ffmpeg, "-y", "-loglevel", "warning"]
        for clip in plan.clips:
            cmd += ["-i", str(clip.path)]
        for track in plan.audio_tracks:
            cmd += ["-i", str(track.path)]

        # 计算每个 clip 的时长参数
        for clip in plan.clips:
            if clip.end_ms is not None and clip.start_ms > 0:
                ss_ms = clip.start_ms / 1000.0
                dur_ms = (clip.end_ms - clip.start_ms) / 1000.0
                cmd += ["-ss", str(ss_ms), "-t", str(dur_ms)]
            elif clip.end_ms is not None:
                dur_ms = clip.end_ms / 1000.0
                cmd += ["-t", str(dur_ms)]
            elif clip.start_ms > 0:
                ss_ms = clip.start_ms / 1000.0
                cmd += ["-ss", str(ss_ms)]

        filter_arg = f"-vf\"{final_video_filter}\""
        if audio_filter_complex:
            cmd += ["-filter_complex", audio_filter_complex, "-map", "[outv]", "-map", "[outa]"]
        else:
            cmd += ["-vf", final_video_filter]

        cmd += [
            "-c:v", "libx264",
            "-preset", "fast",
            "-b:v", plan.output_bitrate,
            "-c:a", "aac",
            "-b:a", "128k",
            "-shortest",
            str(output_path),
        ]

        self._run(cmd)

        if not output_path.exists():
            raise RuntimeError(f"FFmpeg 输出失败，文件未生成: {output_path}")

        duration_ms = self._get_duration_ms(output_path)
        file_size = output_path.stat().st_size

        return EditResult(
            output_path=output_path,
            duration_ms=duration_ms,
            provider=self.name,
            file_size_bytes=file_size,
       )
