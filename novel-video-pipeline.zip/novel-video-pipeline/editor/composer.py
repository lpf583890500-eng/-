"""
editor/composer.py - 视频合成器
将视频片段、音频、字幕统一组装为完整视频。
负责素材路径解析 + EditPlan 构建 + 调用 EditorProvider。
"""
from pathlib import Path
from typing import Optional

from .base import (
    AudioTrack,
    EditPlan,
    EditResult,
    EditorProvider,
    SubtitleOverlay,
    VideoClip,
)


class VideoComposer:
    """视频合成器：高级编排接口"""

    def __init__(self, editor: EditorProvider):
        self.editor = editor

    def compose(
        self,
        video_clips: list[Path] | list[VideoClip],
        audio_tracks: Optional[list[Path] | list[AudioTrack]] = None,
        subtitle_srt: Optional[Path] = None,
        output_path: Path = Path("output.mp4"),
        *,
        output_width: int = 1080,
        output_height: int = 1920,
        output_fps: int = 30,
        output_bitrate: str = "8M",
        transition: str = "cut",
    ) -> EditResult:
        """
        统一合成接口。

        Args:
            video_clips: 视频片段路径列表或 VideoClip 列表
            audio_tracks: 音频路径列表或 AudioTrack 列表
            subtitle_srt: SRT 字幕文件路径
            output_path: 输出路径
            output_width/output_height: 输出分辨率
            output_fps: 输出帧率
            output_bitrate: 输出码率
            transition: 转场类型
        """
        # 统一转换为 VideoClip
        clips = [
            c if isinstance(c, VideoClip) else VideoClip(path=Path(c))
            for c in video_clips
        ]

        # 统一转换为 AudioTrack
        audio: list[AudioTrack] = []
        if audio_tracks:
            for a in audio_tracks:
                if isinstance(a, AudioTrack):
                    audio.append(a)
                else:
                    audio.append(AudioTrack(path=Path(a)))

        # SubtitleOverlay
        subtitle_overlay = None
        if subtitle_srt:
            subtitle_overlay = SubtitleOverlay(srt_path=Path(subtitle_srt))

        plan = EditPlan(
            clips=clips,
            audio_tracks=audio,
            subtitle_overlay=subtitle_overlay,
            output_width=output_width,
            output_height=output_height,
            output_fps=output_fps,
            output_bitrate=output_bitrate,
            transition=transition,
        )

        return self.editor.assemble(plan, output_path)

    def compose_from_storyboard(
        self,
        storyboard: list[dict],
        assets_dir: Path,
        narration_audio: Path,
        subtitle_srt: Optional[Path],
        output_path: Path,
        *,
        bgm_track: Optional[Path] = None,
        output_width: int = 1080,
        output_height: int = 1920,
    ) -> EditResult:
        """
        从分镜剧本合成视频（高级接口）。

        storyboard: list[dict]，每项包含:
            - video_clip_path: str
            - start_ms: int (可选)
            - end_ms: int (可选)
            - speed: float (可选)
        """
        clips: list[VideoClip] = []
        for shot in storyboard:
            clip_path = assets_dir / shot["video_clip_path"]
            clips.append(VideoClip(
                path=clip_path,
                start_ms=shot.get("start_ms", 0),
                end_ms=shot.get("end_ms"),
                speed=shot.get("speed", 1.0),
            ))

        audio_tracks = [AudioTrack(path=narration_audio, volume=1.0)]
        if bgm_track:
            audio_tracks.append(AudioTrack(path=bgm_track, volume=0.3))

        return self.compose(
            video_clips=clips,
            audio_tracks=audio_tracks,
            subtitle_srt=subtitle_srt,
            output_path=output_path,
            output_width=output_width,
            output_height=output_height,
        )
