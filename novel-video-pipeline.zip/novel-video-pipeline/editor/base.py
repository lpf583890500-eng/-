"""
editor/base.py - 视频剪辑 Provider 抽象基类
定义视频剪辑接口：剪切、拼接、转码、字幕烧录、音频混流。
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class VideoClip:
    """单个视频片段"""
    path: Path
    start_ms: int = 0          # 切入时间（毫秒）
    end_ms: Optional[int] = None  # 切出时间（毫秒），None=直到结尾
    speed: float = 1.0          # 播放速率


@dataclass
class AudioTrack:
    """音轨"""
    path: Path
    start_ms: int = 0          # 混入起始时间
    duration_ms: Optional[int] = None  # 截断时长，None=完整
    volume: float = 1.0         # 音量倍率


@dataclass
class SubtitleOverlay:
    """字幕叠加层"""
    srt_path: Path             # SRT 文件路径
    style: str = "default"     # 样式名称


@dataclass
class EditPlan:
    """剪辑计划：描述完整视频输出需求"""
    clips: list[VideoClip] = field(default_factory=list)
    audio_tracks: list[AudioTrack] = field(default_factory=list)
    subtitle_overlay: Optional[SubtitleOverlay] = None
    output_format: str = "mp4"
    output_width: int = 1080
    output_height: int = 1920   # 竖屏短视频默认
    output_fps: int = 30
    output_bitrate: str = "8M"
    transition: str = "cut"     # cut / fade / dissolve


@dataclass
class EditResult:
    """剪辑结果"""
    output_path: Path
    duration_ms: int
    provider: str
    file_size_bytes: int


class EditorProvider(ABC):
    """视频剪辑 Provider 抽象基类"""

    name: str = "base"

    @abstractmethod
    def assemble(
        self,
        plan: EditPlan,
        output_path: Path,
        *,
        progress_callback: Optional[callable] = None,
    ) -> EditResult:
        """
        根据 EditPlan 组装完整视频。

        Args:
            plan: 剪辑计划
            output_path: 输出文件路径
            progress_callback: 进度回调 (percent: float) -> None

        Returns:
            EditResult: 输出路径、时长、Provider 名称
        """
        ...

    def close(self) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
