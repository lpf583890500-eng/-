"""
editor/test_editor.py - editor 模块测试
DTT 规范：测试接口签名、工厂分发、VideoComposer 逻辑
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from editor.base import (
    AudioTrack,
    EditPlan,
    EditResult,
    EditorProvider,
    SubtitleOverlay,
    VideoClip,
)
from editor.composer import VideoComposer
from editor.factory import create_editor_provider, list_supported_providers


class TestVideoClip:
    """VideoClip 数据类测试"""

    def test_clip_defaults(self, tmp_path):
        clip = VideoClip(path=tmp_path / "a.mp4")
        assert clip.start_ms == 0
        assert clip.end_ms is None
        assert clip.speed == 1.0


class TestAudioTrack:
    """AudioTrack 数据类测试"""

    def test_track_defaults(self, tmp_path):
        track = AudioTrack(path=tmp_path / "b.mp3")
        assert track.start_ms == 0
        assert track.duration_ms is None
        assert track.volume == 1.0


class TestEditPlan:
    """EditPlan 测试"""

    def test_plan_defaults(self):
        plan = EditPlan(clips=[])
        assert plan.output_format == "mp4"
        assert plan.output_width == 1080
        assert plan.output_height == 1920
        assert plan.output_fps == 30
        assert plan.transition == "cut"

    def test_plan_with_clips(self, tmp_path):
        clips = [VideoClip(path=tmp_path / "a.mp4")]
        audio = [AudioTrack(path=tmp_path / "b.mp3")]
        sub = SubtitleOverlay(srt_path=tmp_path / "sub.srt")
        plan = EditPlan(
            clips=clips,
            audio_tracks=audio,
            subtitle_overlay=sub,
            output_width=720,
            output_height=1280,
        )
        assert len(plan.clips) == 1
        assert len(plan.audio_tracks) == 1
        assert plan.subtitle_overlay.style == "default"


class TestEditResult:
    """EditResult 数据类测试"""

    def test_result_creation(self, tmp_path):
        result = EditResult(
            output_path=tmp_path / "out.mp4",
            duration_ms=5000,
            provider="ffmpeg",
            file_size_bytes=102400,
        )
        assert result.duration_ms == 5000
        assert result.provider == "ffmpeg"


class TestEditorProviderInterface:
    """EditorProvider 抽象接口测试"""

    def test_editor_is_abc(self):
        assert issubclass(EditorProvider, __import__("abc").ABC)

    def test_assemble_is_abstract(self):
        with pytest.raises(TypeError):
            EditorProvider()  # type: ignore

    def test_context_manager(self):
        from editor.ffmpeg_editor import FFmpegEditorProvider
        # FFmpegEditorProvider 需要 ffmpeg 二进制，实例化不报错（ffmpeg路径检查在运行时）
        editor = FFmpegEditorProvider()
        with editor as e:
            assert e is editor


class TestFactory:
    """工厂函数测试"""

    def test_list_providers(self):
        providers = list_supported_providers()
        assert "ffmpeg" in providers

    def test_create_ffmpeg_provider(self):
        editor = create_editor_provider("ffmpeg")
        assert editor.name == "ffmpeg"

    def test_create_ffmpeg_explicit(self):
        editor = create_editor_provider(provider="ffmpeg")
        assert editor.name == "ffmpeg"

    def test_create_unknown_raises(self):
        with pytest.raises(ValueError) as exc:
            create_editor_provider("premiere")
        assert "premiere" in str(exc.value)

    def test_case_insensitive(self):
        editor = create_editor_provider("FFMPEG")
        assert editor.name == "ffmpeg"


class TestVideoComposer:
    """VideoComposer 高级接口测试"""

    def test_compose_single_clip(self, tmp_path):
        from editor.factory import create_editor_provider
        editor = create_editor_provider()
        composer = VideoComposer(editor)

        video_path = tmp_path / "clip.mp4"
        video_path.write_text("")
        out = tmp_path / "out.mp4"

        # 不调用真实 ffmpeg，只测 composer 是否正确构建 EditPlan
        # Mock assemble 避免真实调用
        original_assemble = editor.assemble
        captured_plan = []

        def mock_assemble(plan, out_path, **kwargs):
            captured_plan.append(plan)
            return EditResult(output_path=out_path, duration_ms=0, provider="mock", file_size_bytes=0)

        editor.assemble = mock_assemble

        result = composer.compose(
            video_clips=[video_path],
            output_path=out,
        )
        assert len(captured_plan) == 1
        assert len(captured_plan[0].clips) == 1

    def test_compose_with_audio_and_subtitle(self, tmp_path):
        from editor.factory import create_editor_provider
        editor = create_editor_provider()
        composer = VideoComposer(editor)

        video_path = tmp_path / "clip.mp4"
        audio_path = tmp_path / "narration.mp3"
        srt_path = tmp_path / "sub.srt"
        out = tmp_path / "out.mp4"
        for p in [video_path, audio_path, srt_path]:
            p.write_text("")

        captured_plan = []

        def mock_assemble(plan, out_path, **kwargs):
            captured_plan.append(plan)
            return EditResult(output_path=out_path, duration_ms=0, provider="mock", file_size_bytes=0)

        editor.assemble = mock_assemble

        composer.compose(
            video_clips=[video_path],
            audio_tracks=[audio_path],
            subtitle_srt=srt_path,
            output_path=out,
            output_width=720,
            output_height=1280,
        )

        plan = captured_plan[0]
        assert len(plan.audio_tracks) == 1
        assert plan.subtitle_overlay is not None
        assert plan.subtitle_overlay.srt_path == srt_path

    def test_compose_respects_resolution(self, tmp_path):
        from editor.factory import create_editor_provider
        editor = create_editor_provider()
        composer = VideoComposer(editor)

        video_path = tmp_path / "clip.mp4"
        video_path.write_text("")
        out = tmp_path / "out.mp4"

        captured_plan = []

        def mock_assemble(plan, out_path, **kwargs):
            captured_plan.append(plan)
            return EditResult(output_path=out_path, duration_ms=0, provider="mock", file_size_bytes=0)

        editor.assemble = mock_assemble

        composer.compose(
            video_clips=[video_path],
            output_path=out,
            output_width=720,
            output_height=1280,
        )

        plan = captured_plan[0]
        assert plan.output_width == 720
        assert plan.output_height == 1280

    def test_compose_accepts_video_clips_objects(self, tmp_path):
        from editor.factory import create_editor_provider
        editor = create_editor_provider()
        composer = VideoComposer(editor)

        video_path = tmp_path / "clip.mp4"
        video_path.write_text("")
        out = tmp_path / "out.mp4"

        captured_plan = []

        def mock_assemble(plan, out_path, **kwargs):
            captured_plan.append(plan)
            return EditResult(output_path=out_path, duration_ms=0, provider="mock", file_size_bytes=0)

        editor.assemble = mock_assemble

        clips = [VideoClip(path=video_path, start_ms=1000, end_ms=5000)]
        composer.compose(video_clips=clips, output_path=out)

        plan = captured_plan[0]
        assert plan.clips[0].start_ms == 1000
        assert plan.clips[0].end_ms == 5000

    def test_compose_from_storyboard(self, tmp_path):
        from editor.factory import create_editor_provider
        editor = create_editor_provider()
        composer = VideoComposer(editor)

        assets_dir = tmp_path / "assets"
        assets_dir.mkdir()
        (assets_dir / "shot1.mp4").write_text("")
        (assets_dir / "shot2.mp4").write_text("")
        narration = tmp_path / "narration.mp3"
        narration.write_text("")
        out = tmp_path / "out.mp4"

        storyboard = [
            {"video_clip_path": "shot1.mp4", "start_ms": 0, "end_ms": 3000},
            {"video_clip_path": "shot2.mp4", "start_ms": 500, "end_ms": 8000},
        ]

        captured_plan = []

        def mock_assemble(plan, out_path, **kwargs):
            captured_plan.append(plan)
            return EditResult(output_path=out_path, duration_ms=0, provider="mock", file_size_bytes=0)

        editor.assemble = mock_assemble

        composer.compose_from_storyboard(
            storyboard=storyboard,
            assets_dir=assets_dir,
            narration_audio=narration,
            subtitle_srt=None,
            output_path=out,
        )

        plan = captured_plan[0]
        assert len(plan.clips) == 2
        assert plan.clips[0].path.name == "shot1.mp4"
        assert plan.clips[0].end_ms == 3000


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
