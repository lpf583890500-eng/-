"""
editor/factory.py - Editor Provider 工厂
"""
from .base import EditorProvider
from .ffmpeg_editor import FFmpegEditorProvider

_PROVIDER_MAP = {
    "ffmpeg": FFmpegEditorProvider,
}


def create_editor_provider(provider: str = "ffmpeg", **kwargs) -> EditorProvider:
    """创建 Editor Provider 实例"""
    provider = provider.lower()
    cls = _PROVIDER_MAP.get(provider)
    if cls is None:
        available = ", ".join(_PROVIDER_MAP.keys())
        raise ValueError(f"不支持的 Editor Provider: {provider}，可用: {available}")
    return cls(**kwargs)


def list_supported_providers() -> list[str]:
    return list(_PROVIDER_MAP.keys())
