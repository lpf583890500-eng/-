"""
editor/__init__.py - 视频剪辑模块
"""
from .base import (
    AudioTrack,
    EditPlan,
    EditResult,
    EditorProvider,
    SubtitleOverlay,
    VideoClip,
)
from .composer import VideoComposer
from .factory import create_editor_provider, list_supported_providers

__all__ = [
    "AudioTrack",
    "EditPlan",
    "EditResult",
    "EditorProvider",
    "SubtitleOverlay",
    "VideoClip",
    "VideoComposer",
    "create_editor_provider",
    "list_supported_providers",
]
