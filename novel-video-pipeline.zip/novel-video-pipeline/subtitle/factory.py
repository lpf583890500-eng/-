"""
subtitle/factory.py - ASR Provider 工厂
"""
from typing import Optional

from .base import ASRProvider
from .whisper_asr import WhisperASRProvider

_PROVIDER_MAP = {
    "whisper": WhisperASRProvider,
}


def create_asr_provider(
    provider: str,
    **kwargs,
) -> ASRProvider:
    """创建 ASR Provider 实例"""
    provider = provider.lower()
    cls = _PROVIDER_MAP.get(provider)
    if cls is None:
        available = ", ".join(_PROVIDER_MAP.keys())
        raise ValueError(f"不支持的 ASR Provider: {provider}，可用: {available}")
    return cls(**kwargs)


def list_supported_providers() -> list[str]:
    return list(_PROVIDER_MAP.keys())
