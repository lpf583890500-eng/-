"""
subtitle/test_subtitle.py - 字幕模块测试
DTT 规范：测试接口签名、格式化输出、工厂分发
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from subtitle.base import ASRProvider, SubtitleCue, SubtitleTrack
from subtitle.formatters import SRTFormatter, ASSFormatter, TimelineAligner
from subtitle.factory import create_asr_provider, list_supported_providers


class TestSubtitleCue:
    """SubtitleCue 数据类测试"""

    def test_cue_creation(self):
        cue = SubtitleCue(index=1, start_ms=1000, end_ms=3000, text="测试字幕")
        assert cue.index == 1
        assert cue.start_ms == 1000
        assert cue.end_ms == 3000
        assert cue.text == "测试字幕"


class TestSubtitleTrack:
    """SubtitleTrack 测试"""

    def test_track_empty(self):
        track = SubtitleTrack()
        assert track.cues == []
        assert track.total_duration_ms() == 0

    def test_track_total_duration(self):
        cues = [
            SubtitleCue(1, 0, 2000, "第一句"),
            SubtitleCue(2, 2000, 5000, "第二句"),
        ]
        track = SubtitleTrack(cues=cues, provider="test")
        assert track.total_duration_ms() == 5000

    def test_to_srt(self):
        cues = [
            SubtitleCue(1, 0, 2000, "第一句"),
            SubtitleCue(2, 2000, 4500, "第二句"),
        ]
        track = SubtitleTrack(cues=cues)
        srt = track.to_srt()
        assert "1\n00:00:00,000 --> 00:00:02,000\n第一句" in srt
        assert "2\n00:00:02,000 --> 00:00:04,500\n第二句" in srt

    def test_to_ass(self):
        cues = [SubtitleCue(1, 0, 2000, "第一句")]
        track = SubtitleTrack(cues=cues)
        ass = track.to_ass()
        assert "[Script Info]" in ass
        assert "[V4+ Styles]" in ass
        assert "[Events]" in ass
        assert "第一句" in ass

    def test_save_srt(self, tmp_path):
        cues = [SubtitleCue(1, 0, 1000, "hello")]
        track = SubtitleTrack(cues=cues)
        out = tmp_path / "test.srt"
        track.save(out, format="srt")
        content = out.read_text(encoding="utf-8")
        assert "hello" in content
        assert "-->" in content

    def test_save_ass(self, tmp_path):
        cues = [SubtitleCue(1, 0, 1000, "hello")]
        track = SubtitleTrack(cues=cues)
        out = tmp_path / "test.ass"
        track.save(out, format="ass")
        content = out.read_text(encoding="utf-8")
        assert "[Script Info]" in content

    def test_save_unknown_format_raises(self, tmp_path):
        track = SubtitleTrack(cues=[])
        with pytest.raises(ValueError) as exc:
            track.save(tmp_path / "x.vtt", format="vtt")
        assert "不支持的格式" in str(exc.value)


class TestSRTFormatter:
    """SRTFormatter 测试"""

    def test_format_single_cue(self):
        cue = SubtitleCue(1, 0, 2500, "测试")
        track = SubtitleTrack(cues=[cue])
        srt = SRTFormatter.format(track)
        lines = srt.split("\n")
        assert "1" == lines[0]
        assert "00:00:00,000 --> 00:00:02,500" == lines[1]
        assert "测试" == lines[2]

    def test_format_multiple_cues(self):
        cues = [
            SubtitleCue(1, 0, 1000, "A"),
            SubtitleCue(2, 1000, 2000, "B"),
        ]
        srt = SRTFormatter.format(SubtitleTrack(cues=cues))
        assert "A" in srt
        assert "B" in srt
        assert "-->" in srt


class TestASSFormatter:
    """ASSFormatter 测试"""

    def test_format_contains_sections(self):
        cue = SubtitleCue(1, 0, 1000, "HI")
        ass = ASSFormatter.format(SubtitleTrack(cues=[cue]))
        assert "[Script Info]" in ass
        assert "[V4+ Styles]" in ass
        assert "[Events]" in ass
        assert "Dialogue:" in ass


class TestTimelineAligner:
    """TimelineAligner 测试"""

    def test_align_single_text(self):
        texts = ["这是一段小说配音文案"]
        track = TimelineAligner.align(texts, audio_duration_ms=5000)
        assert len(track.cues) == 1
        assert track.cues[0].start_ms == 0

    def test_align_multiple_texts(self):
        texts = ["第一句", "第二句", "第三句"]
        track = TimelineAligner.align(texts, audio_duration_ms=6000)
        assert len(track.cues) == 3
        assert track.cues[0].text == "第一句"
        assert track.cues[2].text == "第三句"
        # 验证时间轴递增
        assert track.cues[0].end_ms == track.cues[1].start_ms
        assert track.cues[1].end_ms == track.cues[2].start_ms


class TestASRProviderInterface:
    """ASRProvider 抽象接口测试"""

    def test_asr_is_abc(self):
        assert issubclass(ASRProvider, __import__("abc").ABC)

    def test_transcribe_is_abstract(self):
        with pytest.raises(TypeError):
            ASRProvider()  # type: ignore

    def test_context_manager(self):
        from subtitle.whisper_asr import WhisperASRProvider
        provider = WhisperASRProvider(local_model="tiny")
        with provider as p:
            assert p is provider


class TestFactory:
    """工厂函数测试"""

    def test_list_supported_providers(self):
        providers = list_supported_providers()
        assert "whisper" in providers

    def test_create_whisper_api_provider(self):
        provider = create_asr_provider("whisper", api_key="sk-test")
        assert provider.name == "whisper"
        assert provider.api_key == "sk-test"

    def test_create_whisper_local_provider(self):
        provider = create_asr_provider("whisper", local_model="base")
        assert provider.name == "whisper"
        assert provider.local_model == "base"

    def test_create_unknown_raises(self):
        with pytest.raises(ValueError) as exc:
            create_asr_provider("unknown_asr")
        assert "unknown_asr" in str(exc.value)

    def test_case_insensitive(self):
        provider = create_asr_provider("WHISPER", api_key="x")
        assert provider.name == "whisper"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
