"""
subtitle/whisper_asr.py - OpenAI Whisper ASR 适配器
支持 OpenAI Whisper API 和本地 Whisper 模型。
"""
from pathlib import Path
from typing import Optional

import requests

from .base import ASRProvider, SubtitleCue, SubtitleTrack


class WhisperASRProvider(ASRProvider):
    """OpenAI Whisper ASR 适配器（支持 API 和本地模型）"""

    name = "whisper"

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: str = "whisper-1",
        base_url: Optional[str] = None,
        local_model: Optional[str] = None,  # 如 "base", "medium"
        device: str = "cpu",
    ):
        """
        Args:
            api_key: OpenAI API Key（传入则使用 API，否则尝试本地模型）
            model: API 模型名称
            base_url: API 基础 URL（如 Azure OpenAI）
            local_model: 本地模型名称（whisper.cpp 或 transformers）
            device: 本地推理设备 "cpu" / "cuda"
        """
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.local_model = local_model
        self.device = device

    def transcribe(
        self,
        audio_path: Path,
        *,
        language: Optional[str] = None,
        prompt: Optional[str] = None,
    ) -> SubtitleTrack:
        audio_path = Path(audio_path)
        if not audio_path.exists():
            raise FileNotFoundError(f"音频文件不存在: {audio_path}")

        if self.api_key:
            return self._transcribe_api(audio_path, language, prompt)
        elif self.local_model:
            return self._transcribe_local(audio_path, language, prompt)
        else:
            raise ValueError(
                "必须提供 api_key（使用 Whisper API）或 local_model（使用本地模型）"
            )

    def _transcribe_api(
        self,
        audio_path: Path,
        language: Optional[str],
        prompt: Optional[str],
    ) -> SubtitleTrack:
        url = (self.base_url or "https://api.openai.com") + "/v1/audio/transcriptions"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        files = {"file": open(audio_path, "rb")}
        data = {"model": self.model}
        if language:
            data["language"] = language
        if prompt:
            data["prompt"] = prompt

        resp = requests.post(url, headers=headers, files=files, data=data, timeout=120)
        if resp.status_code != 200:
            raise RuntimeError(f"Whisper API 错误 {resp.status_code}: {resp.text}")

        result = resp.json()
        # API 返回纯文本（无时间轴），使用语音检测工具获取段落
        # 简化：返回单条字幕
        text = result.get("text", "").strip()
        if not text:
            return SubtitleTrack(cues=[], provider=self.name)

        # 粗估：假设音频为正常语速（150字/分钟）
        duration_ms = int(len(text) / 150 * 60 * 1000)
        cue = SubtitleCue(
            index=1,
            start_ms=0,
            end_ms=max(duration_ms, 1000),
            text=text,
        )
        return SubtitleTrack(cues=[cue], language=language, provider=self.name)

    def _transcribe_local(
        self,
        audio_path: Path,
        language: Optional[str],
        prompt: Optional[str],
    ) -> SubtitleTrack:
        try:
            import whisper
        except ImportError:
            raise ImportError("本地 Whisper 未安装: pip install openai-whisper")

        model = whisper.load_model(self.local_model or "base", device=self.device)
        result = model.transcribe(
            str(audio_path),
            language=language,
            initial_prompt=prompt,
        )
        cues = []
        for i, seg in enumerate(result.get("segments", [])):
            cues.append(SubtitleCue(
                index=i + 1,
                start_ms=int(seg["start"] * 1000),
                end_ms=int(seg["end"] * 1000),
                text=seg["text"].strip(),
            ))
        return SubtitleTrack(cues=cues, language=language or result.get("language"), provider=self.name)

    def close(self):
        pass
