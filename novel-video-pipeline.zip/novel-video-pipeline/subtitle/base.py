"""
subtitle/base.py - 字幕 Provider 抽象基类
定义 ASR（自动语音识别）和字幕格式化的标准接口。
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class SubtitleCue:
    """单条字幕条目"""
    index: int           # 序号
    start_ms: int        # 开始时间（毫秒）
    end_ms: int          # 结束时间（毫秒）
    text: str            # 字幕文本


@dataclass
class SubtitleTrack:
    """完整字幕轨道"""
    cues: list[SubtitleCue] = field(default_factory=list)
    language: Optional[str] = None
    provider: str = "base"

    def total_duration_ms(self) -> int:
        """返回字幕总时长（毫秒）"""
        if not self.cues:
            return 0
        return max(c.end_ms for c in self.cues)

    def to_srt(self) -> str:
        """导出为 SRT 格式字符串"""
        from .formatters import SRTFormatter
        return SRTFormatter.format(self)

    def to_ass(self) -> str:
        """导出为 ASS 格式字符串"""
        from .formatters import ASSFormatter
        return ASSFormatter.format(self)

    def save(self, path: Path, format: str = "srt") -> None:
        """保存字幕文件"""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if format.lower() == "srt":
            path.write_text(self.to_srt(), encoding="utf-8")
        elif format.lower() == "ass":
            path.write_text(self.to_ass(), encoding="utf-8")
        else:
            raise ValueError(f"不支持的格式: {format}，可用: srt, ass")


class ASRProvider(ABC):
    """ASR Provider 抽象基类（音频→字幕轨道）"""

    name: str = "base"

    @abstractmethod
    def transcribe(
        self,
        audio_path: Path,
        *,
        language: Optional[str] = None,
        prompt: Optional[str] = None,
    ) -> SubtitleTrack:
        """
        将音频文件转写为字幕轨道。

        Args:
            audio_path: 音频文件路径
            language: 语言代码（如 "zh"，留空则自动检测）
            prompt: 可选提示词，帮助模型理解上下文

        Returns:
            SubtitleTrack: 包含时间轴和文本的字幕轨道
        """
        ...

    def close(self) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
