"""
cli/main.py - CLI 入口
"""
import sys
from pathlib import Path

from .commands import cmd_config, cmd_run, cmd_status
from .parser import parse_args


def main(argv: list[str] | None = None) -> int:
    """CLI 主入口"""
    args = parse_args(argv)

    if args.command == "run":
        return cmd_run(args)
    elif args.command == "config":
        return cmd_config(args)
    elif args.command == "status":
        return cmd_status(args)
    else:
        print(f"未知命令: {args.command}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())