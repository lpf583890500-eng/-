"""
cli/parser.py - CLI 参数解析器
基于 argparse 实现，支持 run / config / status 三大命令。
"""
import argparse
import sys
from pathlib import Path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="novel-video",
        description="短视频小说改文改视频智能体",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # run 命令：输入小说文本运行流水线
    run_parser = sub.add_parser("run", help="运行流水线")
    run_parser.add_argument("novel", help="小说文本或 .txt 文件路径")
    run_parser.add_argument("-o", "--output", default="./output", help="输出目录")
    run_parser.add_argument("-c", "--config", default="config.yaml", help="配置文件路径")
    run_parser.add_argument("--llm-key", help="LLM API Key（覆盖配置）")
    run_parser.add_argument("--tts-key", help="TTS API Key（覆盖配置）")
    run_parser.add_argument("--video-key", help="视频生成 API Key（覆盖配置）")
    run_parser.add_argument("-v", "--verbose", action="store_true", help="详细输出")
    run_parser.add_argument(
        "--interactive", "-i", action="store_true", help="交互式输入小说文本"
    )

    # config 命令：管理配置
    config_parser = sub.add_parser("config", help="查看/编辑配置")
    config_parser.add_argument("action", choices=["show", "init", "set"], default="show")
    config_parser.add_argument("key", nargs="?", help="配置键（如 llm.provider）")
    config_parser.add_argument("value", nargs="?", help="配置值")

    # status 命令：查看运行状态
    status_parser = sub.add_parser("status", help="查看流水线状态")
    status_parser.add_argument("--job-id", help="任务 ID")

    # version
    parser.add_argument("--version", action="version", version="%(prog)s 0.1.0")

    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """解析命令行参数"""
    parser = build_parser()
    args = parser.parse_args(argv)
    return args