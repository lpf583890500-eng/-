"""
cli/commands.py - CLI 命令实现
处理 run / config / status 三大命令的具体逻辑。
"""
import getpass
import sys
from pathlib import Path
from typing import Optional

import json

from pipeline import PipelineConfig, PipelineRunner


def _load_config(config_path: Path) -> PipelineConfig:
    """从 JSON 文件加载配置"""
    if not config_path.exists():
        return PipelineConfig()
    with open(config_path) as f:
        data = json.load(f) or {}
    return PipelineConfig(**data)


def _save_config(config: PipelineConfig, config_path: Path) -> None:
    """保存配置到 JSON 文件"""
    with open(config_path, "w") as f:
        json.dump({
            "output_dir": str(config.output_dir),
            "verbose": config.verbose,
            "resume_on_error": config.resume_on_error,
        }, f, indent=2, ensure_ascii=False)


def _read_novel(novel_input: str, interactive: bool = False) -> str:
    """读取小说文本"""
    if interactive:
        print("请输入小说文本（输入 EOF 或 Ctrl+D 结束）：")
        lines = sys.stdin.read().strip()
        return lines

    novel_path = Path(novel_input)
    if novel_path.exists() and novel_path.suffix == ".txt":
        return novel_path.read_text(encoding="utf-8")
    # 直接当作文本
    return novel_input


def _mask_key(key: str) -> str:
    """脱敏 API Key"""
    if not key or len(key) < 8:
        return "****"
    return key[:4] + "****" + key[-4:]


def cmd_run(args) -> int:
    """执行 run 命令"""
    config_path = Path(args.config)
    config = _load_config(config_path)

    # 覆盖配置
    if args.output:
        config.output_dir = Path(args.output)
    if args.llm_key:
        config.llm.api_key = args.llm_key
    if args.tts_key:
        config.tts.api_key = args.tts_key
    if args.video_key:
        config.video_gen.api_key = args.video_key
    if args.verbose:
        config.verbose = True

    novel_text = _read_novel(args.novel, args.interactive)
    if not novel_text.strip():
        print("错误：小说文本为空", file=sys.stderr)
        return 1

    print(f"📖 文本长度：{len(novel_text)} 字")
    print(f"📁 输出目录：{config.output_dir}")
    print(f"🔧 LLM Provider：{config.llm.provider}")
    print(f"🎙️  TTS Provider：{config.tts.provider}")
    print(f"🎬  Video Provider：{config.video_gen.provider}")
    print()

    runner = PipelineRunner(config)

    def progress_cb(stage: str, pct: float):
        print(f"\r  ⏳ {stage}: {pct:.0%}", end="", flush=True)

    try:
        result = runner.run(novel_text, progress_callback=progress_cb)
        print()  # 换行
    except Exception as e:
        print(f"\n错误：{e}", file=sys.stderr)
        return 1

    if result["success"]:
        print(f"✅ 完成！输出文件：{result['final_output']}")
        print(f"⏱️  总耗时：{result['total_duration_s']:.1f}s")
        print(f"📊 阶段数：{len(result['stage_results'])}")
        return 0
    else:
        print("❌ 流水线执行失败", file=sys.stderr)
        for r in result["stage_results"]:
            if not r.success:
                print(f"  - {r.stage_name} 失败：{r.error}", file=sys.stderr)
        return 1


def cmd_config(args) -> int:
    """执行 config 命令"""
    config_path = Path("config.yaml")
    config = _load_config(config_path)

    if args.action == "show":
        print("=== 流水线配置 ===")
        print(f"输出目录: {config.output_dir}")
        print(f"LLM: {config.llm.provider} / {_mask_key(config.llm.api_key)}")
        print(f"TTS: {config.tts.provider} / {_mask_key(config.tts.api_key)}")
        print(f"VideoGen: {config.video_gen.provider} / {_mask_key(config.video_gen.api_key)}")
        print(f"Audio BGM: {config.audio.music_provider} / {_mask_key(config.audio.music_api_key)}")
        print(f"Editor: {config.editor.provider}")
        return 0

    elif args.action == "init":
        _save_config(config, config_path)
        print(f"✅ 配置文件已生成：{config_path}")
        return 0

    elif args.action == "set":
        if not args.key or not args.value:
            print("用法：novel-video config set <key> <value>", file=sys.stderr)
            return 1
        print(f"设置 {args.key} = {args.value}（支持但需手动编辑 config.yaml）")
        return 0


def cmd_status(args) -> int:
    """执行 status 命令"""
    print("📊 查看状态（当前版本不支持持久化任务跟踪）")
    print("提示：流水线运行日志可在 output/ 目录查看")
    return 0