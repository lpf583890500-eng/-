"""
cli/test_cli.py - CLI 模块测试
DTT 规范：测试参数解析、命令分发、帮助信息
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from cli.parser import build_parser, parse_args


class TestParser:
    """参数解析器测试"""

    def test_parse_run_with_text(self):
        args = parse_args(["run", "这是一段小说文本"])
        assert args.command == "run"
        assert args.novel == "这是一段小说文本"
        assert args.output == "./output"
        assert args.interactive is False

    def test_parse_run_with_file(self):
        args = parse_args(["run", "/path/to/novel.txt", "-o", "/tmp/out"])
        assert args.novel == "/path/to/novel.txt"
        assert args.output == "/tmp/out"

    def test_parse_run_with_api_keys(self):
        args = parse_args([
            "run", "text",
            "--llm-key", "sk-test123",
            "--tts-key", "tts-key",
            "--video-key", "vid-key",
        ])
        assert args.llm_key == "sk-test123"
        assert args.tts_key == "tts-key"
        assert args.video_key == "vid-key"

    def test_parse_run_interactive(self):
        args = parse_args(["run", "text", "-i"])
        assert args.interactive is True
        assert args.verbose is False

    def test_parse_run_verbose(self):
        args = parse_args(["run", "text", "-v"])
        assert args.verbose is True

    def test_parse_config_show(self):
        args = parse_args(["config", "show"])
        assert args.command == "config"
        assert args.action == "show"

    def test_parse_config_set(self):
        args = parse_args(["config", "set", "llm.provider", "azure"])
        assert args.action == "set"
        assert args.key == "llm.provider"
        assert args.value == "azure"

    def test_parse_status(self):
        args = parse_args(["status"])
        assert args.command == "status"

    def test_parse_status_with_job_id(self):
        args = parse_args(["status", "--job-id", "abc123"])
        assert args.job_id == "abc123"

    def test_parse_unknown_command_exits(self):
        with pytest.raises(SystemExit):
            parse_args(["unknown"])


class TestHelpOutput:
    """帮助信息测试"""

    def test_help_shows_commands(self):
        parser = build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["--help"])


class TestCLICommands:
    """CLI 命令测试（Mock 模式）"""

    def test_cmd_status_returns_zero(self):
        from cli.commands import cmd_status
        class MockArgs:
            job_id = None
        result = cmd_status(MockArgs())
        assert result == 0

    def test_cmd_config_show_works(self, tmp_path, monkeypatch):
        """Verify config show runs without error"""
        from cli.commands import cmd_config
        class MockArgs:
            action = "show"
        result = cmd_config(MockArgs())
        assert result == 0


class TestCLIMain:
    """CLI 主入口测试"""

    def test_main_run_empty_novel_returns_1(self):
        from cli.main import main
        # empty novel text -> returns 1
        result = main(["run", ""])
        assert result == 1

    def test_main_config_show_returns_0(self):
        from cli.main import main
        result = main(["config", "show"])
        assert result == 0

    def test_main_status_returns_0(self):
        from cli.main import main
        result = main(["status"])
        assert result == 0

    def test_main_unknown_command_exits_with_2(self):
        from cli.main import main
        # unknown command raises SystemExit(2) from argparse
        with pytest.raises(SystemExit) as exc_info:
            main(["unknown_cmd"])
        assert exc_info.value.code == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])