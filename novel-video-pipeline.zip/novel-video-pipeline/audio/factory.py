"""
audio/factory.py - Audio Provider 工厂
"""
from .base import MusicGenProvider, SFXProvider
from .music_gen import FreeMusicProvider, SunoMusicGenProvider
from .sfx import LocalSFXProvider


def create_music_provider(
    provider: str,
    **kwargs,
) -> MusicGenProvider:
    """创建 BGM 生成 Provider"""
    provider = provider.lower()
    _MAP = {"suno": SunoMusicGenProvider, "free": FreeMusicProvider}
    cls = _MAP.get(provider)
    if cls is None:
        raise ValueError(f"不支持的 BGM Provider: {provider}，可用: {', '.join(_MAP)}")
    return cls(**kwargs)


def create_sfx_provider(
    provider: str,
    **kwargs,
) -> SFXProvider:
    """创建音效 Provider"""
    provider = provider.lower()
    _MAP = {"local": LocalSFXProvider}
    cls = _MAP.get(provider)
    if cls is None:
        raise ValueError(f"不支持的 SFX Provider: {provider}，可用: {', '.join(_MAP)}")
    return cls(**kwargs)


def list_music_providers() -> list[str]:
    return ["suno", "free"]


def list_sfx_providers() -> list[str]:
    return ["local"]