"""
audio/__init__.py - 音频模块
"""
from .base import AudioClip, BGMResult, MusicGenProvider, SFXProvider, SFXResult
from .factory import (
    create_music_provider,
    create_sfx_provider,
    list_music_providers,
    list_sfx_providers,
)

__all__ = [
    "AudioClip",
    "BGMResult",
    "MusicGenProvider",
    "SFXProvider",
    "SFXResult",
    "create_music_provider",
    "create_sfx_provider",
    "list_music_providers",
    "list_sfx_providers",
]