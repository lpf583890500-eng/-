"""
audio/test_audio.py - 音频模块测试
DTT 规范：测试接口签名、工厂分发、Provider 实例化
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from audio.base import (
    AudioClip,
    BGMResult,
    MusicGenProvider,
    SFXProvider,
    SFXResult,
)
from audio.factory import (
    create_music_provider,
    create_sfx_provider,
    list_music_providers,
    list_sfx_providers,
)


class TestAudioClip:
    """AudioClip 数据类测试"""

    def test_clip_defaults(self, tmp_path):
        clip = AudioClip(path=tmp_path / "bgm.mp3")
        assert clip.start_ms == 0
        assert clip.duration_ms is None
        assert clip.volume == 1.0
        assert clip.fade_in_ms == 0
        assert clip.fade_out_ms == 0

    def test_clip_custom(self, tmp_path):
        clip = AudioClip(
            path=tmp_path / "bgm.mp3",
            start_ms=1000,
            duration_ms=5000,
            volume=0.7,
            fade_in_ms=200,
            fade_out_ms=300,
        )
        assert clip.start_ms == 1000
        assert clip.duration_ms == 5000
        assert clip.volume == 0.7
        assert clip.fade_in_ms == 200
        assert clip.fade_out_ms == 300


class TestBGMResult:
    """BGMResult 数据类测试"""

    def test_result_creation(self, tmp_path):
        result = BGMResult(
            output_path=tmp_path / "out.mp3",
            duration_ms=30000,
            provider="suno",
            tags=["calm", "ambient"],
        )
        assert result.duration_ms == 30000
        assert result.provider == "suno"
        assert "calm" in result.tags


class TestSFXResult:
    """SFXResult 数据类测试"""

    def test_result_creation(self, tmp_path):
        result = SFXResult(
            path=tmp_path / "whoosh.mp3",
            name="whoosh",
            category="ui",
            duration_ms=500,
        )
        assert result.name == "whoosh"
        assert result.category == "ui"
        assert result.duration_ms == 500


class TestMusicGenProviderInterface:
    """MusicGenProvider 抽象接口测试"""

    def test_music_gen_is_abc(self):
        assert issubclass(MusicGenProvider, __import__("abc").ABC)

    def test_generate_is_abstract(self):
        with pytest.raises(TypeError):
            MusicGenProvider()  # type: ignore

    def test_context_manager(self):
        from audio.music_gen import FreeMusicProvider
        provider = FreeMusicProvider()
        with provider as p:
            assert p is provider


class TestSFXProviderInterface:
    """SFXProvider 抽象接口测试"""

    def test_sfx_is_abc(self):
        assert issubclass(SFXProvider, __import__("abc").ABC)

    def test_search_is_abstract(self):
        with pytest.raises(TypeError):
            SFXProvider()  # type: ignore


class TestSunoMusicGenProvider:
    """SunoMusicGenProvider 实例化测试"""

    def test_init(self):
        from audio.music_gen import SunoMusicGenProvider
        provider = SunoMusicGenProvider(api_key="test-key")
        assert provider.api_key == "test-key"
        assert provider.name == "suno"
        assert provider.base_url == "https://api.suno.ai"

    def test_init_custom_base_url(self):
        from audio.music_gen import SunoMusicGenProvider
        provider = SunoMusicGenProvider(api_key="k", base_url="https://custom.ai")
        assert provider.base_url == "https://custom.ai"


class TestFreeMusicProvider:
    """FreeMusicProvider 实例化测试"""

    def test_init_no_api_key(self):
        from audio.music_gen import FreeMusicProvider
        provider = FreeMusicProvider()
        assert provider.api_key == ""
        assert provider.name == "free"

    def test_init_with_api_key(self):
        from audio.music_gen import FreeMusicProvider
        provider = FreeMusicProvider(api_key="pixabay-key-123")
        assert provider.api_key == "pixabay-key-123"

    def test_generate_no_api_key_returns_empty(self, tmp_path):
        from audio.music_gen import FreeMusicProvider
        provider = FreeMusicProvider()
        out = tmp_path / "out.mp3"
        result = provider.generate("calm ambient", duration_seconds=10.0, output_path=out)
        # 无 API key 时返回空结果
        assert result.provider == "free"
        assert out.exists()


class TestLocalSFXProvider:
    """LocalSFXProvider 实例化测试"""

    def test_init(self, tmp_path):
        from audio.sfx import LocalSFXProvider
        provider = LocalSFXProvider(library_dir=tmp_path)
        assert provider.library_dir == tmp_path
        assert provider.name == "local"

    def test_search_empty_dir(self, tmp_path):
        from audio.sfx import LocalSFXProvider
        provider = LocalSFXProvider(library_dir=tmp_path)
        results = provider.search("whoosh")
        assert results == []

    def test_search_with_mock_files(self, tmp_path):
        from audio.sfx import LocalSFXProvider
        # 创建模拟音效文件
        sfx_dir = tmp_path / "sfx"
        sfx_dir.mkdir()
        (sfx_dir / "ui__click.mp3").write_text("dummy")
        (sfx_dir / "nature__wind.mp3").write_text("dummy")

        provider = LocalSFXProvider(library_dir=sfx_dir)
        results = provider.search("click")
        assert len(results) == 1
        assert results[0].name == "click"

    def test_search_case_insensitive(self, tmp_path):
        from audio.sfx import LocalSFXProvider
        sfx_dir = tmp_path / "sfx"
        sfx_dir.mkdir()
        (sfx_dir / "battle__explosion.mp3").write_text("dummy")

        provider = LocalSFXProvider(library_dir=sfx_dir)
        results = provider.search("EXPLOSION")
        assert len(results) == 1

    def test_search_category_filter(self, tmp_path):
        from audio.sfx import LocalSFXProvider
        sfx_dir = tmp_path / "sfx"
        sfx_dir.mkdir()
        (sfx_dir / "ui__click.mp3").write_text("dummy")
        (sfx_dir / "nature__wind.mp3").write_text("dummy")

        provider = LocalSFXProvider(library_dir=sfx_dir)
        results = provider.search("click", category="nature")
        assert len(results) == 0  # click 在 ui，不在 nature


class TestFactory:
    """工厂函数测试"""

    def test_list_music_providers(self):
        providers = list_music_providers()
        assert "suno" in providers
        assert "free" in providers

    def test_list_sfx_providers(self):
        providers = list_sfx_providers()
        assert "local" in providers

    def test_create_suno_provider(self):
        provider = create_music_provider("suno", api_key="test-key")
        assert provider.name == "suno"

    def test_create_free_provider(self):
        provider = create_music_provider("free")
        assert provider.name == "free"

    def test_create_local_sfx_provider(self, tmp_path):
        provider = create_sfx_provider("local", library_dir=tmp_path)
        assert provider.name == "local"

    def test_create_unknown_music_raises(self):
        with pytest.raises(ValueError) as exc:
            create_music_provider("aiffy")
        assert "aiffy" in str(exc.value)

    def test_create_unknown_sfx_raises(self):
        with pytest.raises(ValueError) as exc:
            create_sfx_provider("online")
        assert "online" in str(exc.value)

    def test_case_insensitive(self):
        provider = create_music_provider("SUNO", api_key="x")
        assert provider.name == "suno"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])