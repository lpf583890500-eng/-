"""
audio/music_gen.py - 音乐生成 Provider
支持 Suno API / 本地音乐生成 / 免费音乐库降级。
"""
import hashlib
import shutil
import tempfile
from pathlib import Path
from typing import Optional

import requests

from .base import BGMResult, MusicGenProvider


class SunoMusicGenProvider(MusicGenProvider):
    """Suno AI 音乐生成适配器"""

    name = "suno"

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.suno.ai",
        *,
        timeout: int = 120,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def generate(
        self,
        prompt: str,
        duration_seconds: float = 30.0,
        *,
        mood: Optional[str] = None,
        tempo: Optional[int] = None,
        output_path: Optional[Path] = None,
    ) -> BGMResult:
        payload = {
            "prompt": prompt,
            "duration": duration_seconds,
            "make_instrumental": True,
        }
        if mood:
            payload["tags"] = mood
        if tempo:
            payload["tempo"] = tempo

        headers = {"Authorization": f"Bearer {self.api_key}"}
        resp = requests.post(
            f"{self.base_url}/generate",
            headers=headers,
            json=payload,
            timeout=self.timeout,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"Suno API 错误 {resp.status_code}: {resp.text}")

        result = resp.json()
        audio_url = result.get("audio_url")
        if not audio_url:
            raise RuntimeError("Suno 未返回 audio_url")

        output_path = output_path or Path(tempfile.mktemp(suffix=".mp3"))
        output_path.parent.mkdir(parents=True, exist_ok=True)

        audio_resp = requests.get(audio_url, timeout=self.timeout)
        audio_resp.raise_for_status()
        output_path.write_bytes(audio_resp.content)

        return BGMResult(
            output_path=output_path,
            duration_ms=int(duration_seconds * 1000),
            provider=self.name,
            tags=[mood] if mood else [],
        )


class FreeMusicProvider(MusicGenProvider):
    """免费音乐库降级 Provider（从 Pixabay 等免费 API 获取）"""

    name = "free"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://pixabay.com/api",
        *,
        timeout: int = 30,
    ):
        self.api_key = api_key or ""
        self.base_url = base_url
        self.timeout = timeout

    def generate(
        self,
        prompt: str,
        duration_seconds: float = 30.0,
        *,
        mood: Optional[str] = None,
        tempo: Optional[int] = None,
        output_path: Optional[Path] = None,
    ) -> BGMResult:
        """从免费音乐库搜索匹配的音乐（降级方案）"""
        if not self.api_key:
            # 无 API Key 时写入空 MP3 占位文件
            output_path = output_path or Path(tempfile.mktemp(suffix=".mp3"))
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(b"")
            return BGMResult(
                output_path=output_path,
                duration_ms=int(duration_seconds * 1000),
                provider=self.name,
                tags=[],
            )

        params = {
            "key": self.api_key,
            "q": f"{prompt} {'calm' if mood == 'calm' else 'upbeat'}",
            "media_type": "music",
            "duration": f"0-{int(duration_seconds + 5)}",
            "per_page": 1,
        }
        resp = requests.get(self.base_url, params=params, timeout=self.timeout)
        if resp.status_code != 200:
            raise RuntimeError(f"Pixabay API 错误 {resp.status_code}: {resp.text}")

        data = resp.json()
        hits = data.get("hits", [])
        if not hits:
            raise RuntimeError(f"未找到匹配的音乐: {prompt}")

        audio_url = hits[0]["audio"]
        output_path = output_path or Path(tempfile.mktemp(suffix=".mp3"))
        output_path.parent.mkdir(parents=True, exist_ok=True)

        audio_resp = requests.get(audio_url, timeout=self.timeout)
        audio_resp.raise_for_status()
        output_path.write_bytes(audio_resp.content)

        return BGMResult(
            output_path=output_path,
            duration_ms=int(duration_seconds * 1000),
            provider=self.name,
            tags=[mood] if mood else [],
        )