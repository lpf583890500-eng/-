"""
audio/base.py - 音频 Provider 抽象基类
定义 BGM 生成和音效管理的标准接口。
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class AudioClip:
    """单个音频片段"""
    path: Path
    start_ms: int = 0
    duration_ms: Optional[int] = None
    volume: float = 1.0
    fade_in_ms: int = 0
    fade_out_ms: int = 0


@dataclass
class BGMResult:
    """BGM 生成结果"""
    output_path: Path
    duration_ms: int
    provider: str
    tags: list[str] = field(default_factory=list)


@dataclass
class SFXResult:
    """音效搜索结果"""
    path: Path
    name: str
    category: str
    duration_ms: int


class MusicGenProvider(ABC):
    """BGM 生成 Provider 抽象基类"""

    name: str = "base"

    @abstractmethod
    def generate(
        self,
        prompt: str,
        duration_seconds: float = 30.0,
        *,
        mood: Optional[str] = None,
        tempo: Optional[int] = None,
        output_path: Optional[Path] = None,
    ) -> BGMResult:
        """
        根据提示词生成背景音乐。

        Args:
            prompt: 音乐描述（如 " uplifting corporate ambient"）
            duration_seconds: 时长（秒）
            mood: 情绪标签（happy / sad / energetic / calm）
            tempo: BPM（可选）
            output_path: 输出路径（可选，自动生成）

        Returns:
            BGMResult: 输出路径、时长、Provider、标签
        """
        ...

    def close(self) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class SFXProvider(ABC):
    """音效库 Provider 抽象基类"""

    name: str = "base"

    @abstractmethod
    def search(
        self,
        query: str,
        *,
        category: Optional[str] = None,
        limit: int = 10,
    ) -> list[SFXResult]:
        """
        搜索匹配的音效。

        Args:
            query: 搜索关键词（如 "whoosh", "footsteps"）
            category: 音效分类（如 "nature", "ui", "battle"）
            limit: 返回数量上限

        Returns:
            list[SFXResult]: 匹配的音效列表
        """
        ...

    def close(self) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()