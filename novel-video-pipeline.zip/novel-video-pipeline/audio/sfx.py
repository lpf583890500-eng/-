"""
audio/sfx.py - 音效库 Provider
支持本地音效库管理和搜索。
"""
from pathlib import Path
from typing import Optional

from .base import SFXProvider, SFXResult


class LocalSFXProvider(SFXProvider):
    """本地音效库 Provider（扫描本地目录）"""

    name = "local"

    def __init__(
        self,
        library_dir: Path,
        *,
        supported_formats: tuple[str, ...] = (".mp3", ".wav", ".ogg", ".m4a"),
    ):
        self.library_dir = Path(library_dir)
        self.supported_formats = supported_formats
        self._cache: Optional[list[SFXResult]] = None

    def _scan_library(self) -> list[SFXResult]:
        """扫描本地目录，构建音效索引"""
        results = []
        if not self.library_dir.exists():
            return results

        for audio_file in self.library_dir.rglob("*"):
            if audio_file.suffix.lower() in self.supported_formats:
                # 从文件名解析信息：category__name.duration
                name = audio_file.stem
                parts = name.split("__")
                if len(parts) >= 2:
                    category = parts[0]
                    display_name = parts[1]
                else:
                    category = audio_file.parent.name
                    display_name = name

                # 估算时长（文件大小 / 128kbps）
                size = audio_file.stat().st_size
                duration_ms = int(size / 16000 * 1000)

                results.append(SFXResult(
                    path=audio_file,
                    name=display_name,
                    category=category,
                    duration_ms=duration_ms,
                ))
        return results

    def search(
        self,
        query: str,
        *,
        category: Optional[str] = None,
        limit: int = 10,
    ) -> list[SFXResult]:
        if self._cache is None:
            self._cache = self._scan_library()

        query_lower = query.lower()
        results = [
            r for r in self._cache
            if query_lower in r.name.lower() or query_lower in r.category.lower()
        ]
        if category:
            results = [r for r in results if r.category == category]

        return results[:limit]

    def close(self) -> None:
        self._cache = None