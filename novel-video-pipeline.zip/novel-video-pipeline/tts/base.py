"""
tts/base.py - TTS Provider 抽象基类
定义所有 TTS 适配器必须实现的接口。
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class TTSResult:
    """TTS 生成结果"""
    audio_path: Path          # 生成的音频文件路径
    duration: float           # 音频时长（秒）
    provider: str             # 来源 Provider 名称


class TTSProvider(ABC):
    """TTS Provider 抽象基类"""

    name: str = "base"  # 子类覆盖

    @abstractmethod
    def synthesize(
        self,
        text: str,
        output_path: Path,
        *,
        voice: Optional[str] = None,
        speed: float = 1.0,
        language: Optional[str] = None,
    ) -> TTSResult:
        """
        将文本转为语音并保存为音频文件。

        Args:
            text: 要转换的文本
            output_path: 输出文件路径（.wav 或 .mp3）
            voice: 声音标识（Provider 自定义）
            speed: 语速倍率（0.5~2.0）
            language: 语言代码（如 "zh-CN"）

        Returns:
            TTSResult: 包含音频路径、时长、Provider 名称
        """
        ...

    @abstractmethod
    def list_voices(self) -> list[dict]:
        """返回可用声音列表，每项包含 id, name, language, gender"""
        ...

    def close(self) -> None:
        """清理资源（子类可选覆盖）"""
        pass

    def __enter__(self) -> "TTSProvider":
        return self

    def __exit__(self, *args) -> None:
        self.close()
