"""
tts/gpt_sovits.py - GPT-SoVITS 本地/远程 API 适配器
支持本地部署的 GPT-SoVITS API 服务
文档: https://github.com/RVC-Boss/GPT-SoVITS
"""
import subprocess
import time
from pathlib import Path
from typing import Optional

import requests

from .base import TTSProvider, TTSResult


class GPTSovitsProvider(TTSProvider):
    """GPT-SoVITS TTS 适配器（支持本地或远程 API）"""

    name = "gpt_sovits"

    def __init__(
        self,
        base_url: str = "http://localhost:9876",
        *,
        default_voice: str = "female_chinese",
        timeout: int = 120,
    ):
        self.base_url = base_url.rstrip("/")
        self.default_voice = default_voice
        self.timeout = timeout

    def synthesize(
        self,
        text: str,
        output_path: Path,
        *,
        voice: Optional[str] = None,
        speed: float = 1.0,
        language: Optional[str] = None,
    ) -> TTSResult:
        voice = voice or self.default_voice
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # GPT-SoVITS API 格式
        payload = {
            "text": text,
            "text_lang": language or "zh",
            "ref_audio_path": "",          # 可扩展：参考音频路径
            "prompt_lang": language or "zh",
            "prompt_text": "",
            "top_k": 15,
            "top_p": 0.6,
            "temperature": 0.6,
            "speed_factor": speed,         # 0.5~2.0
        }

        resp = requests.post(
            f"{self.base_url}/tts",
            json=payload,
            timeout=self.timeout,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"GPT-SoVITS API 错误 {resp.status_code}: {resp.text}")

        audio_data = resp.content
        output_path.write_bytes(audio_data)

        # 粗估时长（假设 16kHz 采样率）
        duration = len(audio_data) / 32000.0

        return TTSResult(audio_path=output_path, duration=duration, provider=self.name)

    def list_voices(self) -> list[dict]:
        """返回已配置的声音列表（需要服务端支持）"""
        try:
            resp = requests.get(f"{self.base_url}/voices", timeout=10)
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        return [
            {"id": "female_chinese", "name": "中文女声（默认）", "language": "zh-CN", "gender": "female"},
            {"id": "male_chinese", "name": "中文男声", "language": "zh-CN", "gender": "male"},
        ]

    def close(self) -> None:
        pass
