"""
tts/__init__.py - TTS 模块
"""
from .base import TTSProvider, TTSResult
from .factory import create_tts_provider, list_supported_providers

__all__ = [
    "TTSProvider",
    "TTSResult",
    "create_tts_provider",
    "list_supported_providers",
]
