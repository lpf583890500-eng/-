"""
tts/test_tts.py - TTS 模块测试
DTT 规范：每 Provider 至少 3 个用例，测试接口签名 + 异常 + 工厂分发
"""
import sys
import tempfile
from pathlib import Path

import pytest

# 确保 tts 模块可导入
sys.path.insert(0, str(Path(__file__).parent.parent))

from tts.base import TTSProvider, TTSResult
from tts.factory import create_tts_provider, list_supported_providers


class TestTTSResult:
    """TTSResult 数据类测试"""

    def test_tts_result_creation(self, tmp_path):
        result = TTSResult(
            audio_path=tmp_path / "test.mp3",
            duration=3.5,
            provider="test",
        )
        assert result.duration == 3.5
        assert result.provider == "test"
        assert result.audio_path.name == "test.mp3"

    def test_tts_result_immutable(self, tmp_path):
        result = TTSResult(audio_path=tmp_path, duration=1.0, provider="x")
        with pytest.raises(AttributeError):
            result.duration = 2.0


class TestTTSProviderInterface:
    """TTSProvider 抽象接口测试"""

    def test_base_is_abc(self):
        assert issubclass(TTSProvider, __import__("abc").ABC)

    def test_synthesize_is_abstract(self):
        """TTSProvider 是 ABC，不能直接实例化"""
        with pytest.raises(TypeError):
            TTSProvider()  # type: ignore

    def test_list_voices_is_abstract(self):
        """TTSProvider 是 ABC，抽象方法必须在子类实现"""
        with pytest.raises(TypeError):
            TTSProvider()  # type: ignore

    def test_context_manager(self, tmp_path):
        """支持 with 语法"""
        # TTSProvider 是 ABC，不能直接实例化；用子类验证 with 协议
        from tts.cosyvoice import CosyVoiceProvider
        provider = CosyVoiceProvider(api_key="k", secret_key="s")
        with provider as p:
            assert p is provider


class TestAzureProviderInstantiation:
    """Azure TTS Provider 实例化测试"""

    def test_azure_import_error_if_missing_dep(self):
        """无依赖时抛出 ImportError"""
        # 验证当 azure SDK 未安装时 ImportError 被正确抛出
        import tts.azure as azure_module
        original = azure_module._AZURE_AVAILABLE
        azure_module._AZURE_AVAILABLE = False
        try:
            with pytest.raises(ImportError):
                azure_module.AzureTTSProvider(api_key="x", region="eastus")
        finally:
            azure_module._AZURE_AVAILABLE = original

    def test_azure_init_params(self):
        """验证构造函数参数（需要 azure SDK）"""
        import pytest
        pytest.importorskip("azure.cognitiveservices.speech", reason="Azure SDK not installed")
        from tts.azure import AzureTTSProvider
        params = {"api_key": "test-key", "region": "eastus", "default_voice": "zh-CN-XiaoxiaoNeural"}
        provider = AzureTTSProvider(**params)
        assert provider.api_key == "test-key"
        assert provider.region == "eastus"
        assert provider.name == "azure"


class TestCosyVoiceProviderInstantiation:
    """CosyVoice Provider 实例化测试"""

    def test_cosyvoice_init(self):
        from tts.cosyvoice import CosyVoiceProvider
        provider = CosyVoiceProvider(
            api_key="test-key",
            secret_key="test-secret",
            app_id="test-app",
        )
        assert provider.app_id == "test-app"
        assert provider.name == "cosyvoice"

    def test_cosyvoice_default_voice(self):
        from tts.cosyvoice import CosyVoiceProvider
        provider = CosyVoiceProvider(api_key="k", secret_key="s")
        assert provider.default_voice == "zh_CN_female_fengting"

    def test_cosyvoice_list_voices(self):
        from tts.cosyvoice import CosyVoiceProvider
        provider = CosyVoiceProvider(api_key="k", secret_key="s")
        voices = provider.list_voices()
        assert isinstance(voices, list)
        assert all("id" in v and "name" in v for v in voices)


class TestGPTSovitsProviderInstantiation:
    """GPT-SoVITS Provider 实例化测试"""

    def test_gptsovits_init_defaults(self):
        from tts.gpt_sovits import GPTSovitsProvider
        provider = GPTSovitsProvider()
        assert provider.base_url == "http://localhost:9876"
        assert provider.name == "gpt_sovits"

    def test_gptsovits_init_custom(self):
        from tts.gpt_sovits import GPTSovitsProvider
        provider = GPTSovitsProvider(base_url="http://192.168.1.100:9876")
        assert provider.base_url == "http://192.168.1.100:9876"

    def test_gptsovits_list_voices_fallback(self):
        from tts.gpt_sovits import GPTSovitsProvider
        provider = GPTSovitsProvider()
        voices = provider.list_voices()  # 服务不可用时返回默认值
        assert len(voices) >= 2


class TestFactory:
    """工厂函数测试"""

    def test_list_supported_providers(self):
        providers = list_supported_providers()
        assert "azure" in providers
        assert "cosyvoice" in providers
        assert "gpt_sovits" in providers

    def test_create_azure_provider(self):
        pytest.importorskip("azure.cognitiveservices.speech", reason="Azure SDK not installed")
        provider = create_tts_provider("azure", api_key="test-key", region="eastus")
        assert provider.name == "azure"

    def test_create_cosyvoice_provider(self):
        provider = create_tts_provider("cosyvoice", api_key="k", secret_key="s")
        assert provider.name == "cosyvoice"

    def test_create_gpt_sovits_provider(self):
        provider = create_tts_provider("gpt_sovits")
        assert provider.name == "gpt_sovits"

    def test_create_unknown_provider_raises(self):
        with pytest.raises(ValueError) as exc_info:
            create_tts_provider("unknown_tts")
        assert "unknown_tts" in str(exc_info.value)

    def test_create_cosyvoice_case_insensitive(self):
        provider = create_tts_provider("COSYVOICE", api_key="k", secret_key="s")
        assert provider.name == "cosyvoice"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
