"""
tts/azure.py - Azure TTS 适配器
支持 Azure Cognitive Services TTS API (REST & SDK)
"""
from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from .base import TTSProvider, TTSResult

try:
    import azure.cognitiveservices.speech as speech
    _AZURE_AVAILABLE = True
except ImportError:
    _AZURE_AVAILABLE = False
    speech = None  # type: ignore

if TYPE_CHECKING:
    import azure.cognitiveservices.speech as speech


class AzureTTSProvider(TTSProvider):
    """Azure TTS 适配器"""

    name = "azure"

    def __init__(
        self,
        api_key: str,
        region: str = "eastus",
        *,
        default_voice: str = "zh-CN-XiaoxiaoNeural",
        timeout: int = 60,
    ):
        if not _AZURE_AVAILABLE:
            raise ImportError(
                "Azure TTS SDK 未安装，请运行: pip install azure-cognitiveservices-speech"
            )
        self.api_key = api_key
        self.region = region
        self.default_voice = default_voice
        self.timeout = timeout
        self._client: Optional["speech.SpeechConfig"] = None

    def _get_config(self):
        if self._client is None:
            self._client = speech.SpeechConfig(
                subscription=self.api_key, region=self.region
            )
        return self._client

    def synthesize(
        self,
        text: str,
        output_path: Path,
        *,
        voice: Optional[str] = None,
        speed: float = 1.0,
        language: Optional[str] = None,
    ) -> TTSResult:
        config = self._get_config()
        voice = voice or self.default_voice
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        config.speech_synthesis_voice_name = voice
        config.speech_synthesis_output_format = speech.SpeechSynthesisOutputFormat.Audio16Khz32KBitRateMonoMp3

        synthesizer = speech.SpeechSynthesizer(speech_config=config, audio_config=None)
        result = synthesizer.speak_text_async(text).get()
        if result.reason != speech.ResultReason.SynthesizingAudioCompleted:
            raise RuntimeError(f"Azure TTS 合成失败: {result.error_details}")

        audio_data = result.audio_data
        output_path.write_bytes(audio_data)
        duration = len(audio_data) / 2000.0

        return TTSResult(audio_path=output_path, duration=duration, provider=self.name)

    def list_voices(self) -> list[dict]:
        import requests

        url = f"https://voice.{self.region}.batch.azure.com/api/text-to-speech/voices/list"
        headers = {"Ocp-Apim-Subscription-Key": self.api_key}
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        return [
            {"id": v.get("id"), "name": v.get("name"), "language": v.get("locale"), "gender": v.get("gender", "Unknown")}
            for v in data.get("values", [])
        ]

    def close(self) -> None:
        self._client = None
