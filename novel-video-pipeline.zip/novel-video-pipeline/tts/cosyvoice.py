"""
tts/cosyvoice.py - 阿里云 CosyVoice 适配器
支持 CosyVoice API (RESTful)
文档: https://help.aliyun.com/document_detail/2639704.html
"""
import base64
import hashlib
import hmac
import json
import time
import uuid
from pathlib import Path
from typing import Optional

import requests

from .base import TTSProvider, TTSResult


class CosyVoiceProvider(TTSProvider):
    """阿里云 CosyVoice TTS 适配器"""

    name = "cosyvoice"

    def __init__(
        self,
        api_key: str,
        secret_key: str,
        app_id: str = "",
        *,
        default_voice: str = "zh_CN_female_fengting",
        timeout: int = 60,
    ):
        self.app_id = app_id
        self.api_key = api_key
        self.secret_key = secret_key
        self.default_voice = default_voice
        self.timeout = timeout

    def _sign(self, method: str, path: str, body: str = "") -> dict:
        """生成阿里云 API 签名"""
        timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        nonce = str(uuid.uuid4())

        string_to_sign = f"GET\n{path}\n{body}\n{self.app_id}\n{nonce}\n{timestamp}"
        signature = hmac.new(
            self.secret_key.encode(),
            string_to_sign.encode(),
            digestmod=hashlib.sha256,
        ).base64encode().decode()

        return {
            "X-App-Id": self.app_id,
            "X-Nonce": nonce,
            "X-Timestamp": timestamp,
            "X-Signature": signature,
            "Authorization": f"Bearer {self.api_key}",
        }

    def synthesize(
        self,
        text: str,
        output_path: Path,
        *,
        voice: Optional[str] = None,
        speed: float = 1.0,
        language: Optional[str] = None,
    ) -> TTSResult:
        voice = voice or self.default_voice
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # CosyVoice 语速参数映射 (0.5~2.0 -> -500~500)
        rate = int((speed - 1.0) * 500)
        payload = {
            "appid": self.app_id,
            "text": text,
            "voice": voice,
            "encoding": "mp3",
            "rate": rate,
            "language": language or "zh",
        }
        body = json.dumps(payload)

        headers = self._sign("POST", "/api/v1/tts", body)
        headers["Content-Type"] = "application/json"

        resp = requests.post(
            f"https://dashscope.aliyuncs.com/api/v1/tts",
            headers=headers,
            data=body,
            timeout=self.timeout,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"CosyVoice API 错误 {resp.status_code}: {resp.text}")

        # 返回是二进制音频流
        audio_data = resp.content
        output_path.write_bytes(audio_data)

        # 估算时长（mp3 128kbps => 16KB/秒）
        duration = len(audio_data) / 16000.0

        return TTSResult(audio_path=output_path, duration=duration, provider=self.name)

    def list_voices(self) -> list[dict]:
        """返回 CosyVoice 内置声音列表（固定值）"""
        return [
            {"id": "zh_CN_female_fengting", "name": "凤鸣（女声）", "language": "zh-CN", "gender": "female"},
            {"id": "zh_CN_male_yunyang", "name": "云扬（男声）", "language": "zh-CN", "gender": "male"},
            {"id": "zh_CN_female_xiaoyun", "name": "小云（女声）", "language": "zh-CN", "gender": "female"},
            {"id": "en_US_female_jenny", "name": "Jenny（英文女声）", "language": "en-US", "gender": "female"},
            {"id": "en_US_male_ryan", "name": "Ryan（英文男声）", "language": "en-US", "gender": "male"},
        ]
