"""
tts/factory.py - TTS Provider 工厂
通过 provider name 统一创建 TTS 实例。
"""
from typing import Optional

from .azure import AzureTTSProvider
from .base import TTSProvider
from .cosyvoice import CosyVoiceProvider
from .gpt_sovits import GPTSovitsProvider

_PROVIDER_MAP = {
    "azure": AzureTTSProvider,
    "cosyvoice": CosyVoiceProvider,
    "gpt_sovits": GPTSovitsProvider,
}


def create_tts_provider(
    provider: str,
    **kwargs,
) -> TTSProvider:
    """
    创建 TTS Provider 实例。

    Args:
        provider: 提供商名称（azure / cosyvoice / gpt_sovits）
        **kwargs: 传递给 Provider 构造函数的参数

    Returns:
        TTSProvider 实例

    Raises:
        ValueError: 不支持的 provider
        ImportError: 缺少依赖
    """
    provider = provider.lower()
    cls = _PROVIDER_MAP.get(provider)
    if cls is None:
        available = ", ".join(_PROVIDER_MAP.keys())
        raise ValueError(
            f"不支持的 TTS Provider: {provider}，可用: {available}"
        )
    return cls(**kwargs)


def list_supported_providers() -> list[str]:
    """返回支持的 Provider 列表"""
    return list(_PROVIDER_MAP.keys())
