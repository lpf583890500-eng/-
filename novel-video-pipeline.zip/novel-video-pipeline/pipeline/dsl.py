"""
pipeline/dsl.py - Pipeline DSL
定义流水线描述语言：将阶段声明为 Pythonic 的链式调用。
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class StageResult:
    """阶段执行结果"""
    stage_name: str
    output: Any
    duration_seconds: float
    success: bool
    error: Optional[str] = None


class PipelineStage:
    """流水线阶段基类"""

    name: str = "base"

    def run(self, input: Any, config: Any) -> StageResult:
        raise NotImplementedError


class Pipeline:
    """
    流水线描述类。

    用法：
        pipeline = (
            Pipeline()
            .stage("llm_rewrite", RewriteStage())
            .stage("tts", TTSStage())
            .stage("video_gen", VideoGenStage())
            .stage("edit", EditStage())
        )
        results = pipeline.run(novel_text, config)
    """

    def __init__(self):
        self._stages: list[tuple[str, PipelineStage]] = []
        self._skip_stages: set[str] = set()

    def stage(self, name: str, stage: PipelineStage) -> "Pipeline":
        self._stages.append((name, stage))
        return self

    def skip(self, name: str) -> "Pipeline":
        self._skip_stages.add(name)
        return self

    def run(self, input: Any, config: Any) -> list[StageResult]:
        results = []
        for name, stage in self._stages:
            if name in self._skip_stages:
                continue
            import time
            t0 = time.time()
            try:
                output = stage.run(input, config)
                success = True
                error = None
            except Exception as e:
                output = None
                success = False
                error = str(e)
            duration = time.time() - t0
            results.append(StageResult(
                stage_name=name,
                output=output,
                duration_seconds=duration,
                success=success,
                error=error,
            ))
            if not success:
                break
            input = output  # 传递给下一阶段
        return results


# ---- 具体阶段实现 ----

class NovelParseStage(PipelineStage):
    """阶段1：小说文本解析 + 分段"""
    name = "novel_parse"

    def run(self, novel_text: str, config: Any) -> dict:
        """返回结构化的章节列表"""
        from llm import create_llm_provider

        llm = create_llm_provider(config.llm.provider, api_key=config.llm.api_key)
        prompt = (
            f"将以下小说文本拆分为场景段落，返回 JSON 数组，"
            f"每项包含 chapter_title, content:\n\n{novel_text[:2000]}"
        )
        result = llm.generate(prompt)  # 返回 str
        # 简单解析（实际应调用 JSON 解析）
        return {"segments": result.split("\n"), "raw": novel_text}


class RewriteStage(PipelineStage):
    """阶段2：LLM 改写为配音文案"""
    name = "llm_rewrite"

    def run(self, parsed: dict, config: Any) -> list[dict]:
        from llm import create_llm_provider

        llm = create_llm_provider(config.llm.provider, api_key=config.llm.api_key)
        segments = parsed.get("segments", [])
        rewritten = []
        for seg in segments[:8]:  # 限制最多8个段落
            prompt = (
                f"将以下小说片段改写为高潮前置的短视频配音文案，"
                f"50-80字，第三方称，紧张感优先：\n\n{seg}"
            )
            result = llm.generate(prompt)  # 返回 str
            rewritten.append({"original": seg, "script": result})
        return rewritten


class TTSStage(PipelineStage):
    """阶段3：TTS 配音生成"""
    name = "tts"

    def run(self, scripts: list[dict], config: Any) -> list[dict]:
        from tts import create_tts_provider

        tts = create_tts_provider(
            config.tts.provider,
            api_key=config.tts.api_key,
            secret_key=config.tts.secret_key,
            app_id=config.tts.app_id,
        )
        results = []
        for item in scripts:
            script = item["script"]
            out_path = config.output_dir / f"audio_{len(results)}.mp3"
            result = tts.synthesize(script, out_path)
            item["audio_path"] = str(result.audio_path)
            item["duration_ms"] = result.duration * 1000  # 转为毫秒
            results.append(item)
        return results


class SceneExtractStage(PipelineStage):
    """阶段4：场景外观提取"""
    name = "scene_extract"

    def run(self, scripts: list[dict], config: Any) -> list[dict]:
        from llm import create_llm_provider

        llm = create_llm_provider(config.llm.provider, api_key=config.llm.api_key)
        for item in scripts:
            prompt = (
                f"从以下文案提取场景外观描述，纯净、无人物、"
                f"四字以上名称：\n\n{item['script']}"
            )
            result = llm.generate(prompt)  # 返回 str
            item["scene_desc"] = result.strip()
        return scripts


class CharacterExtractStage(PipelineStage):
    """阶段5：角色外观提取"""
    name = "character_extract"

    def run(self, scripts: list[dict], config: Any) -> list[dict]:
        from llm import create_llm_provider

        llm = create_llm_provider(config.llm.provider, api_key=config.llm.api_key)
        for item in scripts:
            prompt = (
                f"从以下文案提取角色外观描述，"
                f"三视图、电影级CG光效、高精度：\n\n{item['script']}"
            )
            result = llm.generate(prompt)  # 返回 str
            item["character_desc"] = result.strip()
        return scripts


class StoryboardStage(PipelineStage):
    """阶段6：分镜剧本生成"""
    name = "storyboard"

    def run(self, scripts: list[dict], config: Any) -> list[dict]:
        from llm import create_llm_provider

        llm = create_llm_provider(config.llm.provider, api_key=config.llm.api_key)
        for item in scripts:
            prompt = (
                f"将以下文案转换为分镜剧本，每节15秒，"
                f"含运镜/音效/台词，适配即梦AI：\n\n{item['script']}"
            )
            result = llm.generate(prompt)  # 返回 str
            item["storyboard"] = result
        return scripts


class VideoGenStage(PipelineStage):
    """阶段7：视频生成"""
    name = "video_gen"

    def run(self, storyboard_items: list[dict], config: Any) -> list[dict]:
        from generator.video_gen import create_video_gen_provider

        video_gen = create_video_gen_provider(
            config.video_gen.provider,
            api_key=config.video_gen.api_key,
            api_secret=config.video_gen.api_secret,
        )
        for idx, item in enumerate(storyboard_items):
            scene_desc = item.get("scene_desc", "")
            character_desc = item.get("character_desc", "")
            prompt = f"{scene_desc},{character_desc}".strip()
            out_path = config.output_dir / f"clip_{idx}.mp4"
            result = video_gen.generate(prompt, duration=15)  # 返回 dict
            item["video_path"] = result.get("video_path", result.get("video_url", ""))
            item["video_duration_ms"] = 15 * 1000  # 默认 15 秒
        return storyboard_items


class EditStage(PipelineStage):
    """阶段8：视频剪辑合成"""
    name = "edit"

    def run(self, clips: list[dict], config: Any) -> dict:
        from editor import VideoComposer, create_editor_provider

        editor = create_editor_provider(config.editor.provider)
        composer = VideoComposer(editor)

        video_paths = [Path(c["video_path"]) for c in clips]
        audio_paths = [Path(c["audio_path"]) for c in clips]
        out_path = config.output_dir / "final.mp4"

        result = composer.compose(
            video_clips=video_paths,
            audio_tracks=audio_paths,
            output_path=out_path,
            output_width=config.editor.output_width,
            output_height=config.editor.output_height,
            output_fps=config.editor.output_fps,
            output_bitrate=config.editor.output_bitrate,
        )
        return {
            "output_path": str(result.output_path),
            "duration_ms": result.duration_ms,
            "file_size": result.file_size_bytes,
        }