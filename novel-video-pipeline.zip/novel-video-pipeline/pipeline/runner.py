"""
pipeline/runner.py - Pipeline 执行器
负责实际运行流水线、处理进度回调、错误恢复。
"""
import time
from pathlib import Path
from typing import Callable, Optional

from .config import PipelineConfig
from .dsl import (
    CharacterExtractStage,
    EditStage,
    NovelParseStage,
    Pipeline,
    RewriteStage,
    SceneExtractStage,
    StoryboardStage,
    TTSStage,
    VideoGenStage,
)


class PipelineRunner:
    """
    流水线执行器。

    用法：
        runner = PipelineRunner(config)
        result = runner.run(novel_text="...", progress_callback=print)
    """

    def __init__(self, config: PipelineConfig):
        self.config = config
        config.output_dir = Path(config.output_dir)
        config.output_dir.mkdir(parents=True, exist_ok=True)

    def run(
        self,
        novel_text: str,
        *,
        progress_callback: Optional[Callable[[str, float], None]] = None,
    ) -> dict:
        """
        运行完整流水线。

        Returns:
            dict: {
                "success": bool,
                "final_output": Path,
                "stage_results": list[StageResult],
                "total_duration_s": float,
            }
        """
        def notify(stage: str, progress: float):
            if progress_callback:
                progress_callback(stage, progress)

        pipeline = (
            Pipeline()
            .stage("novel_parse", NovelParseStage())
            .stage("rewrite", RewriteStage())
            .stage("tts", TTSStage())
            .stage("scene_extract", SceneExtractStage())
            .stage("character_extract", CharacterExtractStage())
            .stage("storyboard", StoryboardStage())
            .stage("video_gen", VideoGenStage())
            .stage("edit", EditStage())
        )

        notify("开始", 0.0)
        t0 = time.time()
        results = pipeline.run(novel_text, self.config)
        total_duration = time.time() - t0

        # 检查结果
        success = all(r.success for r in results)
        final_output = None
        if results:
            last = results[-1]
            if last.success and isinstance(last.output, dict):
                final_output = last.output.get("output_path")

        notify("完成", 1.0)

        return {
            "success": success,
            "final_output": Path(final_output) if final_output else None,
            "stage_results": results,
            "total_duration_s": total_duration,
        }

    def run_with_retry(
        self,
        novel_text: str,
        *,
        max_retries: int = 2,
        progress_callback: Optional[Callable[[str, float], None]] = None,
    ) -> dict:
        """支持从断点重试的运行方式"""
        for attempt in range(max_retries + 1):
            try:
                return self.run(novel_text, progress_callback=progress_callback)
            except Exception as e:
                if attempt == max_retries:
                    raise
                print(f"[Retry] 失败重试 {attempt + 1}/{max_retries}: {e}")
                time.sleep(2)
        return {}