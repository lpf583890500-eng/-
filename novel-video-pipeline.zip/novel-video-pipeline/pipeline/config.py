"""
pipeline/config.py - Pipeline 配置
定义流水线各阶段的配置、密钥、和默认参数。
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class LLMConfig:
    """LLM 配置"""
    provider: str = "openai"
    model: str = "gpt-4o-mini"
    api_key: str = ""
    base_url: Optional[str] = None
    max_retries: int = 3
    timeout: int = 60


@dataclass
class VideoGenConfig:
    """视频生成配置"""
    provider: str = "jimeng"
    api_key: str = ""
    api_secret: str = ""
    model: str = "image-to-video"
    output_width: int = 1280
    output_height: int = 720
    output_fps: int = 30


@dataclass
class TTSConfig:
    """TTS 配置"""
    provider: str = "cosyvoice"
    api_key: str = ""
    secret_key: str = ""
    app_id: str = ""
    default_voice: str = "zh_CN_female_fengting"


@dataclass
class AudioConfig:
    """音频配置（BGM/SFX）"""
    music_provider: str = "free"
    music_api_key: str = ""
    sfx_library_dir: str = "./sfx_library"
    bgm_volume: float = 0.3


@dataclass
class EditorConfig:
    """剪辑配置"""
    provider: str = "ffmpeg"
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    output_width: int = 1080
    output_height: int = 1920
    output_fps: int = 30
    output_bitrate: str = "8M"


@dataclass
class PipelineConfig:
    """完整流水线配置"""
    # 输出目录
    output_dir: Path = Path("./output")

    # 子模块配置
    llm: LLMConfig = field(default_factory=LLMConfig)
    video_gen: VideoGenConfig = field(default_factory=VideoGenConfig)
    tts: TTSConfig = field(default_factory=TTSConfig)
    audio: AudioConfig = field(default_factory=AudioConfig)
    editor: EditorConfig = field(default_factory=EditorConfig)

    # 全局选项
    verbose: bool = True
    resume_on_error: bool = True  # 某阶段失败时从断点继续