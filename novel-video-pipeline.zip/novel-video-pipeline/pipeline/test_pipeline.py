"""
pipeline/test_pipeline.py - Pipeline 模块测试
DTT 规范：测试接口签名、配置、DSL 链式调用、执行结果
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from pipeline.config import (
    AudioConfig,
    EditorConfig,
    LLMConfig,
    PipelineConfig,
    TTSConfig,
    VideoGenConfig,
)
from pipeline.dsl import (
    CharacterExtractStage,
    EditStage,
    NovelParseStage,
    Pipeline,
    RewriteStage,
    SceneExtractStage,
    StageResult,
    StoryboardStage,
    TTSStage,
    VideoGenStage,
)
from pipeline.runner import PipelineRunner


class TestPipelineConfig:
    """PipelineConfig 测试"""

    def test_config_defaults(self, tmp_path):
        config = PipelineConfig(output_dir=tmp_path)
        assert config.verbose is True
        assert config.resume_on_error is True

    def test_config_nested_defaults(self):
        config = PipelineConfig()
        assert config.llm.provider == "openai"
        assert config.video_gen.provider == "jimeng"
        assert config.tts.provider == "cosyvoice"
        assert config.editor.provider == "ffmpeg"

    def test_config_custom_providers(self):
        config = PipelineConfig(
            llm=LLMConfig(provider="azure", model="gpt-4"),
            tts=TTSConfig(provider="azure"),
            audio=AudioConfig(music_provider="suno"),
        )
        assert config.llm.model == "gpt-4"
        assert config.tts.provider == "azure"
        assert config.audio.music_provider == "suno"


class TestStageResult:
    """StageResult 数据类测试"""

    def test_stage_result_creation(self):
        result = StageResult(
            stage_name="tts",
            output={"audio_path": "/tmp/test.mp3"},
            duration_seconds=1.5,
            success=True,
        )
        assert result.stage_name == "tts"
        assert result.duration_seconds == 1.5
        assert result.success

    def test_stage_result_with_error(self):
        result = StageResult(
            stage_name="video_gen",
            output=None,
            duration_seconds=0.5,
            success=False,
            error="API rate limit exceeded",
        )
        assert not result.success
        assert "rate limit" in result.error


class TestPipelineDSL:
    """Pipeline DSL 测试"""

    def test_empty_pipeline(self):
        p = Pipeline()
        assert p._stages == []

    def test_add_single_stage(self):
        p = Pipeline().stage("rewrite", RewriteStage())
        assert len(p._stages) == 1
        assert p._stages[0][0] == "rewrite"

    def test_chain_multiple_stages(self):
        p = (
            Pipeline()
            .stage("parse", NovelParseStage())
            .stage("rewrite", RewriteStage())
            .stage("tts", TTSStage())
        )
        assert len(p._stages) == 3
        assert [n for n, _ in p._stages] == ["parse", "rewrite", "tts"]

    def test_skip_stage(self):
        p = (
            Pipeline()
            .stage("parse", NovelParseStage())
            .stage("rewrite", RewriteStage())
            .skip("parse")
        )
        # parse 被加入 skip 列表，运行时会被跳过
        assert "parse" in p._skip_stages

    def test_pipeline_run_all_success(self):
        """模拟全部成功的流水线"""
        from unittest.mock import MagicMock

        p = Pipeline()

        # Mock 两个阶段
        stage1 = MagicMock()
        stage1.name = "stage1"
        stage1.run.return_value = {"result": "from_s1"}

        stage2 = MagicMock()
        stage2.name = "stage2"
        stage2.run.return_value = {"result": "from_s2"}

        p.stage("s1", stage1).stage("s2", stage2)

        mock_config = MagicMock()
        results = p.run("initial_input", mock_config)

        assert len(results) == 2
        assert results[0].stage_name == "s1"
        assert results[1].stage_name == "s2"
        assert all(r.success for r in results)
        # 验证数据流：stage2 收到 stage1 的输出
        stage2.run.assert_called_once()
        call_args = stage2.run.call_args
        assert call_args[0][0] == {"result": "from_s1"}

    def test_pipeline_run_stops_on_failure(self):
        from unittest.mock import MagicMock

        p = Pipeline()

        stage1 = MagicMock()
        stage1.name = "stage1"
        stage1.run.side_effect = RuntimeError("API error")

        stage2 = MagicMock()
        stage2.name = "stage2"
        stage2.run.side_effect = RuntimeError("Should not run")

        p.stage("s1", stage1).stage("s2", stage2)

        mock_config = MagicMock()
        results = p.run("input", mock_config)

        assert len(results) == 1
        assert not results[0].success
        assert "API error" in results[0].error
        # stage2 不应该被调用
        stage2.run.assert_not_called()


class TestPipelineRunner:
    """PipelineRunner 测试"""

    def test_runner_init_creates_output_dir(self, tmp_path):
        config = PipelineConfig(output_dir=tmp_path / "output")
        runner = PipelineRunner(config)
        assert (tmp_path / "output").exists()

    def test_runner_run_returns_dict_structure(self, tmp_path):
        config = PipelineConfig(output_dir=tmp_path)
        runner = PipelineRunner(config)

        # Mock 所有阶段，避免真实 API 调用
        from unittest.mock import patch, MagicMock
        from pipeline.dsl import Pipeline

        with patch.object(Pipeline, "run") as mock_run:
            mock_run.return_value = [
                StageResult("parse", {"segments": []}, 0.1, True),
                StageResult("rewrite", [{"script": "x"}], 0.2, True),
            ]
            result = runner.run("小说文本")

        assert "success" in result
        assert "stage_results" in result
        assert "total_duration_s" in result
        assert result["total_duration_s"] > 0


class TestStageInterface:
    """各阶段接口签名测试"""

    def test_novel_parse_stage_name(self):
        stage = NovelParseStage()
        assert stage.name == "novel_parse"

    def test_rewrite_stage_name(self):
        stage = RewriteStage()
        assert stage.name == "llm_rewrite"

    def test_tts_stage_name(self):
        stage = TTSStage()
        assert stage.name == "tts"

    def test_scene_extract_stage_name(self):
        stage = SceneExtractStage()
        assert stage.name == "scene_extract"

    def test_character_extract_stage_name(self):
        stage = CharacterExtractStage()
        assert stage.name == "character_extract"

    def test_storyboard_stage_name(self):
        stage = StoryboardStage()
        assert stage.name == "storyboard"

    def test_video_gen_stage_name(self):
        stage = VideoGenStage()
        assert stage.name == "video_gen"

    def test_edit_stage_name(self):
        stage = EditStage()
        assert stage.name == "edit"


class TestAudioConfig:
    """AudioConfig 测试"""

    def test_audio_config_defaults(self):
        config = AudioConfig()
        assert config.music_provider == "free"
        assert config.bgm_volume == 0.3

    def test_audio_config_custom(self):
        config = AudioConfig(music_provider="suno", bgm_volume=0.5)
        assert config.music_provider == "suno"
        assert config.bgm_volume == 0.5


class TestEditorConfig:
    """EditorConfig 测试"""

    def test_editor_config_defaults(self):
        config = EditorConfig()
        assert config.output_width == 1080
        assert config.output_height == 1920
        assert config.output_fps == 30

    def test_editor_config_vertical_video(self):
        config = EditorConfig(output_width=720, output_height=1280)
        assert config.output_height > config.output_width


class TestPipelineIntegration:
    """流水线集成测试（使用 mock）"""

    def test_full_pipeline_runs_all_stages(self, tmp_path):
        from unittest.mock import MagicMock, patch

        config = PipelineConfig(output_dir=tmp_path)
        runner = PipelineRunner(config)

        # Mock 所有阶段的 run 方法
        with patch.object(Pipeline, "run") as mock_run:
            mock_run.return_value = [
                StageResult("novel_parse", {"segments": ["s1", "s2"]}, 0.5, True),
                StageResult("rewrite", [{"script": "配音1"}, {"script": "配音2"}], 1.0, True),
                StageResult("tts", [{"audio_path": "/tmp/a.mp3"}], 2.0, True),
                StageResult("scene_extract", [{}], 0.5, True),
                StageResult("character_extract", [{}], 0.5, True),
                StageResult("storyboard", [{}], 1.0, True),
                StageResult("video_gen", [{"video_path": "/tmp/v.mp4"}], 5.0, True),
                StageResult("edit", {"output_path": "/tmp/out.mp4"}, 3.0, True),
            ]

            result = runner.run("小说文本")

        assert result["success"] is True
        assert len(result["stage_results"]) == 8
        assert result["stage_results"][-1].stage_name == "edit"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])