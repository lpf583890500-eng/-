"""
LLM模块 - 大语言模型调用层
支持OpenAI、Claude等主流LLM接口
"""
from llm.base import BaseLLM
from llm.openai_llm import OpenAILLM
from llm.factory import LLMFactory


def create_llm_provider(provider: str, **kwargs) -> BaseLLM:
    """便捷工厂函数：通过 provider name 创建 LLM 实例"""
    return LLMFactory.create(provider, **kwargs)


__all__ = ["BaseLLM", "OpenAILLM", "LLMFactory", "create_llm_provider"]
