"""
LLM工厂类
统一创建不同类型的LLM实例
"""
import os
import logging
from typing import Optional, Dict, Type

from llm.base import BaseLLM

logger = logging.getLogger(__name__)


class LLMFactory:
    """
    LLM工厂类
    通过统一的接口创建不同类型的LLM实例
    """

    # 注册的LLM类型映射
    _registry: Dict[str, Type[BaseLLM]] = {}

    @classmethod
    def register(cls, name: str, llm_class: Type[BaseLLM]) -> None:
        """
        注册LLM类型

        Args:
            name: LLM类型名称
            llm_class: LLM类
        """
        cls._registry[name.lower()] = llm_class
        logger.debug(f"注册LLM类型: {name} -> {llm_class.__name__}")

    @classmethod
    def create(
        cls,
        llm_type: str,
        api_key: Optional[str] = None,
        model: str = "gpt-4",
        base_url: Optional[str] = None,
        **kwargs
    ) -> BaseLLM:
        """
        创建LLM实例

        Args:
            llm_type: LLM类型 (openai/anthropic/deepseek等)
            api_key: API密钥
            model: 模型名称
            base_url: API基础URL
            **kwargs: 其他参数

        Returns:
            BaseLLM: LLM实例

        Raises:
            ValueError: 不支持的LLM类型
        """
        llm_type = llm_type.lower()

        # 检查是否已注册
        if llm_type not in cls._registry:
            # 尝试自动导入
            if llm_type == "openai":
                cls.register(llm_type, __import__('llm.openai_llm', fromlist=['OpenAILLM']).OpenAILLM)
            elif llm_type == "anthropic":
                cls.register(llm_type, __import__('llm.anthropic_llm', fromlist=['AnthropicLLM']).AnthropicLLM)
            elif llm_type == "deepseek":
                cls.register(llm_type, __import__('llm.deepseek_llm', fromlist=['DeepSeekLLM']).DeepSeekLLM)
            else:
                raise ValueError(
                    f"不支持的LLM类型: {llm_type}。"
                    f"支持的类型: {list(cls._registry.keys())}"
                )

        llm_class = cls._registry[llm_type]

        # 创建实例
        return llm_class(
            api_key=api_key,
            model=model,
            base_url=base_url,
            **kwargs
        )

    @classmethod
    def list_supported(cls) -> list:
        """
        获取支持的LLM类型列表

        Returns:
            list: 支持的LLM类型名称列表
        """
        return list(cls._registry.keys())


# 注册默认支持的LLM类型
def _register_default_llms():
    """注册默认支持的LLM类型"""
    try:
        from llm.openai_llm import OpenAILLM
        LLMFactory.register("openai", OpenAILLM)
        LLMFactory.register("oai", OpenAILLM)  # 别名
    except ImportError:
        pass

    try:
        from llm.anthropic_llm import AnthropicLLM
        LLMFactory.register("anthropic", AnthropicLLM)
        LLMFactory.register("claude", AnthropicLLM)
    except ImportError:
        pass

    try:
        from llm.deepseek_llm import DeepSeekLLM
        LLMFactory.register("deepseek", DeepSeekLLM)
    except ImportError:
        pass


_register_default_llms()
