"""
OpenAI兼容接口实现
支持OpenAI API以及兼容OpenAI格式的第三方API
"""
import os
import time
import logging
from typing import List, Optional, Dict, Any
from pydantic import SecretStr

import openai
import requests

from llm.base import BaseLLM

logger = logging.getLogger(__name__)


class OpenAILLM(BaseLLM):
    """
    OpenAI兼容接口实现

    支持：
    - OpenAI官方API (api.openai.com)
    - 支持OpenAI格式的第三方API (如SiliconFlow、API2D等)
    - Azure OpenAI Service
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-4",
        base_url: Optional[str] = None,
        timeout: int = 60,
        max_retries: int = 3,
        **kwargs
    ):
        """
        初始化OpenAI LLM

        Args:
            api_key: API密钥，默认从环境变量OPENAI_API_KEY读取
            model: 模型名称，默认gpt-4
            base_url: API基础URL，默认OpenAI官方
            timeout: 请求超时时间(秒)
            max_retries: 最大重试次数
            **kwargs: 其他OpenAI客户端参数
        """
        # 从环境变量或参数获取api_key
        if api_key is None:
            api_key = os.getenv("OPENAI_API_KEY", "")

        if not api_key:
            raise ValueError("API Key未设置，请传入api_key或设置OPENAI_API_KEY环境变量")

        super().__init__(
            api_key=api_key,
            model=model,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries
        )

        # 从环境变量获取base_url（如果未传入）
        if self.base_url is None:
            self.base_url = os.getenv("OPENAI_BASE_URL")

        # 初始化OpenAI客户端
        client_kwargs = {
            "api_key": self.api_key,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
        }

        if self.base_url:
            client_kwargs["base_url"] = self.base_url

        # 兼容Azure OpenAI
        azure_api_version = kwargs.pop("azure_api_version", None)
        azure_endpoint = kwargs.pop("azure_endpoint", None)
        if azure_endpoint:
            client_kwargs["azure_endpoint"] = azure_endpoint
            if azure_api_version:
                client_kwargs["api_version"] = azure_api_version
            # Azure不需要base_url
            if "base_url" in client_kwargs:
                del client_kwargs["base_url"]

        self.client = openai.OpenAI(**client_kwargs)
        logger.info(f"OpenAILLM初始化成功，模型: {self.model}")

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        生成单次响应

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词（可选）
            temperature: 温度参数（0-2），越高越有创意
            max_tokens: 最大token数
            **kwargs: 其他OpenAI参数

        Returns:
            str: 生成的文本内容

        Raises:
            ValueError: prompt为空
            APIError: API调用失败
            Timeout: 请求超时
        """
        self._validate_prompt(prompt)

        # 构建消息列表
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        # 构建请求参数
        request_kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            **kwargs
        }

        if max_tokens:
            request_kwargs["max_tokens"] = max_tokens

        # 重试机制
        last_error = None
        for attempt in range(self.max_retries):
            try:
                response = self.client.chat.completions.create(**request_kwargs)
                result = response.choices[0].message.content
                logger.debug(f"生成成功: {result[:50]}...")
                return result

            except requests.Timeout as e:
                last_error = e
                logger.warning(f"请求超时 (尝试 {attempt + 1}/{self.max_retries})")
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)  # 指数退避
                continue

            except Exception as e:
                # 检查是否是API相关错误
                error_type = type(e).__name__
                if "API" in error_type or "Timeout" in error_type or "RateLimit" in error_type:
                    last_error = e
                    logger.warning(f"API相关错误 {error_type} (尝试 {attempt + 1}/{self.max_retries}): {e}")
                else:
                    last_error = e
                    logger.warning(f"未知错误 {error_type} (尝试 {attempt + 1}/{self.max_retries}): {e}")

                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                continue

            except Exception as e:
                logger.error(f"未知错误: {e}")
                raise

        # 所有重试都失败
        logger.error(f"达到最大重试次数({self.max_retries})，最后错误: {last_error}")
        raise last_error

    def batch_generate(
        self,
        prompts: List[str],
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> List[str]:
        """
        批量生成响应

        Args:
            prompts: 用户提示词列表
            system_prompt: 系统提示词（可选）
            temperature: 温度参数
            max_tokens: 最大token数
            **kwargs: 其他参数

        Returns:
            List[str]: 生成的文本列表

        Raises:
            ValueError: prompts为空列表
        """
        if not prompts:
            raise ValueError("prompts列表不能为空")

        results = []
        for i, prompt in enumerate(prompts):
            try:
                result = self.generate(
                    prompt=prompt,
                    system_prompt=system_prompt,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    **kwargs
                )
                results.append(result)
                logger.info(f"批量生成进度: {i + 1}/{len(prompts)}")

            except Exception as e:
                logger.error(f"批量生成失败 (prompt {i + 1}): {e}")
                # 单个失败不影响其他，继续处理
                results.append(f"[错误: {str(e)}]")

        return results

    def generate_with_structured_output(
        self,
        prompt: str,
        response_format: type,
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        生成结构化输出（使用JSON模式）

        Args:
            prompt: 用户提示词
            response_format: 响应格式类型（Pydantic模型）
            system_prompt: 系统提示词
            **kwargs: 其他参数

        Returns:
            Dict[str, Any]: 结构化的响应数据
        """
        self._validate_prompt(prompt)

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        request_kwargs = {
            "model": self.model,
            "messages": messages,
            "response_format": response_format,
            **kwargs
        }

        try:
            response = self.client.chat.completions.create(**request_kwargs)
            return response.choices[0].message.parsed

        except Exception as e:
            logger.error(f"结构化输出生成失败: {e}")
            raise
