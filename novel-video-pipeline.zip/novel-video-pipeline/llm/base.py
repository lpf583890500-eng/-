"""
LLM抽象基类
定义所有LLM实现必须遵循的接口规范
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class LLMConfig(BaseModel):
    """LLM配置模型"""
    api_key: str = Field(..., description="API Key")
    model: str = Field(default="gpt-4", description="模型名称")
    base_url: Optional[str] = Field(default=None, description="API基础URL")
    timeout: int = Field(default=60, description="请求超时时间(秒)")
    max_retries: int = Field(default=3, description="最大重试次数")


class BaseLLM(ABC):
    """
    LLM抽象基类
    所有LLM实现必须继承此类并实现抽象方法
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4",
        base_url: Optional[str] = None,
        timeout: int = 60,
        max_retries: int = 3
    ):
        """
        初始化LLM

        Args:
            api_key: API密钥
            model: 模型名称
            base_url: API基础URL（可选）
            timeout: 请求超时时间(秒)
            max_retries: 最大重试次数
        """
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries

    @abstractmethod
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        生成单次响应

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词（可选）
            temperature: 温度参数（0-1）
            max_tokens: 最大token数
            **kwargs: 其他参数

        Returns:
            str: 生成的文本内容

        Raises:
            ValueError: prompt为空时
            APIError: API调用失败时
        """
        pass

    @abstractmethod
    def batch_generate(
        self,
        prompts: List[str],
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> List[str]:
        """
        批量生成响应

        Args:
            prompts: 用户提示词列表
            system_prompt: 系统提示词（可选）
            temperature: 温度参数
            max_tokens: 最大token数
            **kwargs: 其他参数

        Returns:
            List[str]: 生成的文本列表
        """
        pass

    def _validate_prompt(self, prompt: str) -> None:
        """
        验证prompt有效性

        Args:
            prompt: 待验证的提示词

        Raises:
            ValueError: prompt为空或无效
        """
        if not prompt or not prompt.strip():
            raise ValueError("prompt不能为空")
