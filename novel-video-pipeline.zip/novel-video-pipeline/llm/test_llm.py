"""
LLM模块测试用例
DTT规范：测试用例先行
"""
import pytest
from unittest.mock import Mock, patch, MagicMock


class TestLLMBase:
    """LLM抽象基类测试"""

    def test_base_class_has_abstract_methods(self):
        """测试基类定义了抽象方法"""
        from llm.base import BaseLLM
        assert hasattr(BaseLLM, 'generate')
        assert hasattr(BaseLLM, 'batch_generate')

    def test_base_class_init(self):
        """测试基类初始化参数"""
        from llm.base import BaseLLM
        # 创建实例验证参数
        class TestLLM(BaseLLM):
            def generate(self, prompt, **kwargs):
                return ""
            def batch_generate(self, prompts, **kwargs):
                return []

        llm = TestLLM(api_key="test-key", model="gpt-4", timeout=30)
        assert llm.api_key == "test-key"
        assert llm.model == "gpt-4"
        assert llm.timeout == 30


class TestOpenAILLM:
    """OpenAI兼容接口测试"""

    def test_init_with_params(self):
        """测试直接传参初始化"""
        from llm.openai_llm import OpenAILLM
        llm = OpenAILLM(
            api_key="sk-direct-key",
            model="gpt-4",
            base_url="https://custom.api.com/v1"
        )
        assert llm.api_key == "sk-direct-key"
        assert llm.model == "gpt-4"
        assert llm.base_url == "https://custom.api.com/v1"

    def test_init_missing_api_key(self):
        """测试缺少API Key的处理"""
        import os
        # 清除环境变量
        old_key = os.environ.pop("OPENAI_API_KEY", None)
        old_url = os.environ.pop("OPENAI_BASE_URL", None)

        try:
            from llm.openai_llm import OpenAILLM
            with pytest.raises(ValueError, match="API Key未设置"):
                OpenAILLM()
        finally:
            # 恢复环境变量
            if old_key:
                os.environ["OPENAI_API_KEY"] = old_key
            if old_url:
                os.environ["OPENAI_BASE_URL"] = old_url

    @patch('openai.OpenAI')
    def test_generate_success(self, mock_openai_class):
        """测试正常生成"""
        from llm.openai_llm import OpenAILLM

        # Mock响应
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "测试响应内容"
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_class.return_value = mock_client

        llm = OpenAILLM(api_key="sk-test")
        result = llm.generate("你好，请介绍自己")

        assert result == "测试响应内容"
        mock_client.chat.completions.create.assert_called_once()

    def test_generate_empty_prompt(self):
        """测试空prompt处理"""
        from llm.openai_llm import OpenAILLM
        llm = OpenAILLM(api_key="sk-test")
        with pytest.raises(ValueError, match="prompt不能为空"):
            llm.generate("")

    def test_generate_whitespace_prompt(self):
        """测试纯空白prompt处理"""
        from llm.openai_llm import OpenAILLM
        llm = OpenAILLM(api_key="sk-test")
        with pytest.raises(ValueError, match="prompt不能为空"):
            llm.generate("   ")

    @patch('openai.OpenAI')
    def test_generate_with_system_prompt(self, mock_openai_class):
        """测试带系统提示词的生成"""
        from llm.openai_llm import OpenAILLM

        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "响应"
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_class.return_value = mock_client

        llm = OpenAILLM(api_key="sk-test")
        result = llm.generate(
            prompt="用户问题",
            system_prompt="你是一个助手"
        )

        # 验证system prompt被正确传递
        call_args = mock_client.chat.completions.create.call_args
        messages = call_args.kwargs["messages"]
        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"

    @patch('openai.OpenAI')
    def test_batch_generate_success(self, mock_openai_class):
        """测试批量生成"""
        from llm.openai_llm import OpenAILLM

        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "批量响应"
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_class.return_value = mock_client

        llm = OpenAILLM(api_key="sk-test")
        results = llm.batch_generate(["问题1", "问题2", "问题3"])

        assert len(results) == 3
        assert all(r == "批量响应" for r in results)

    def test_batch_generate_empty_list(self):
        """测试空列表处理"""
        from llm.openai_llm import OpenAILLM
        llm = OpenAILLM(api_key="sk-test")
        with pytest.raises(ValueError, match="prompts列表不能为空"):
            llm.batch_generate([])

    @patch('openai.OpenAI')
    def test_api_error_propagation(self, mock_openai_class):
        """测试API错误向上传播"""
        from llm.openai_llm import OpenAILLM
        import openai

        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("API错误")
        mock_openai_class.return_value = mock_client

        llm = OpenAILLM(api_key="sk-test")

        with pytest.raises(Exception, match="API错误"):
            llm.generate("测试")

    @patch('openai.OpenAI')
    def test_timeout_error_propagation(self, mock_openai_class):
        """测试超时错误向上传播"""
        from llm.openai_llm import OpenAILLM
        import requests

        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = requests.Timeout("请求超时")
        mock_openai_class.return_value = mock_client

        llm = OpenAILLM(api_key="sk-test")

        with pytest.raises(requests.Timeout):
            llm.generate("测试")


class TestLLMFactory:
    """LLM工厂测试"""

    def test_create_openai_llm(self):
        """测试创建OpenAI LLM"""
        from llm.factory import LLMFactory
        llm = LLMFactory.create("openai", api_key="sk-test")
        from llm.openai_llm import OpenAILLM
        assert isinstance(llm, OpenAILLM)

    def test_create_oai_alias(self):
        """测试oai别名"""
        from llm.factory import LLMFactory
        llm = LLMFactory.create("oai", api_key="sk-test")
        from llm.openai_llm import OpenAILLM
        assert isinstance(llm, OpenAILLM)

    def test_create_unsupported_llm(self):
        """测试不支持的LLM类型"""
        from llm.factory import LLMFactory
        with pytest.raises(ValueError, match="不支持的LLM类型"):
            LLMFactory.create("unsupported", api_key="sk-test")

    def test_list_supported(self):
        """测试获取支持的LLM类型"""
        from llm.factory import LLMFactory
        supported = LLMFactory.list_supported()
        assert "openai" in supported or "oai" in supported


class TestLLMIntegration:
    """集成测试（需要真实API Key）"""

    @pytest.mark.skip(reason="需要真实API Key，仅手动测试")
    def test_real_api_call(self):
        """真实API调用测试"""
        import os
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            pytest.skip("需要OPENAI_API_KEY环境变量")

        from llm.openai_llm import OpenAILLM
        llm = OpenAILLM(api_key=api_key)
        result = llm.generate("你好，请用一句话介绍自己")
        assert result is not None
        assert len(result) > 0
