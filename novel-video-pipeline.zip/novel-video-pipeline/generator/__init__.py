"""
生成器模块
包含图片生成和视频生成适配器
"""

from generator.image_gen import ImageGenFactory, JimengImageGenerator, SD20ImageGenerator, WanImageGenerator
from generator.video_gen import VideoGenFactory, KlingVideoGenerator, JimengVideoGenerator, PixverseVideoGenerator

__all__ = [
    # 图片生成
    'ImageGenFactory',
    'JimengImageGenerator',
    'SD20ImageGenerator',
    'WanImageGenerator',
    # 视频生成
    'VideoGenFactory',
    'KlingVideoGenerator',
    'JimengVideoGenerator',
    'PixverseVideoGenerator',
]