"""
Wan（通义万相）图片生成适配器
阿里云通义万相文生图接口
"""
import logging
import time
import requests
from typing import List, Dict, Any, Optional

from generator.image_gen.base import BaseImageGenerator

logger = logging.getLogger(__name__)


class WanImageGenerator(BaseImageGenerator):
    """
    Wan（通义万相）图片生成器

    支持阿里云通义万相的文生图功能
    文档: https://help.aliyun.com/document_detail/WAN.html
    """

    BASE_URL = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-to-image"

    def __init__(
        self,
        api_key: str,
        model: str = "wan-2.1",
        timeout: int = 120,
        max_retries: int = 3
    ):
        """
        初始化Wan图片生成器

        Args:
            api_key: 阿里云API密钥
            model: 模型名称
            timeout: 请求超时
            max_retries: 最大重试次数
        """
        super().__init__(api_key, model, timeout, max_retries)

        self.default_params = {
            "model": self.model,
            "size": "1024x1024",
            "n": 1,
            "style": "auto"
        }

    def get_model_name(self) -> str:
        return f"wan-{self.model}"

    def generate(
        self,
        prompt: str,
        negative_prompt: Optional[str] = None,
        size: str = "1024x1024",
        style: str = "auto",
        **kwargs
    ) -> Dict[str, Any]:
        """
        生成单张图片

        Args:
            prompt: 正向提示词
            negative_prompt: 负向提示词
            size: 图片尺寸
            style: 风格
            **kwargs: 其他参数

        Returns:
            Dict: {
                "image_url": str,
                "image_path": str,
                "request_id": str,
                "data": dict
            }
        """
        self._init_session()

        try:
            # 解析尺寸
            width, height = map(int, size.split('x'))

            # 构建请求参数
            payload = {
                "model": self.model,
                "input": {
                    "prompt": prompt
                },
                "parameters": {
                    "size": f"{width}x{height}",
                    "n": 1,
                    "style": style,
                    **kwargs
                }
            }

            if negative_prompt:
                payload["input"]["negative_prompt"] = negative_prompt

            url = f"{self.BASE_URL}"
            self.logger.info(f"调用Wan API生成图片: {prompt[:50]}...")

            response = self.session.post(
                url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()

            data = response.json()
            self.logger.info(f"Wan API响应成功")

            # 解析响应
            if "output" in data:
                result = {
                    "image_url": data["output"].get("image_url"),
                    "request_id": data.get("request_id"),
                    "data": data
                }
                return result
            elif "data" in data:
                result = {
                    "image_url": data["data"].get("image_url"),
                    "request_id": data.get("request_id"),
                    "data": data
                }
                return result
            else:
                raise Exception(f"API响应格式异常: {data}")

        except requests.Timeout:
            self.logger.error("请求超时")
            raise
        except requests.RequestException as e:
            self.logger.error(f"请求失败: {e}")
            raise
        finally:
            self._cleanup_session()

    def generate_batch(
        self,
        prompts: List[str],
        negative_prompt: Optional[str] = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        批量生成图片

        Args:
            prompts: 提示词列表
            negative_prompt: 负向提示词
            **kwargs: 其他参数

        Returns:
            图片列表
        """
        results = []
        for i, prompt in enumerate(prompts):
            self.logger.info(f"批量生成图片 [{i+1}/{len(prompts)}]")
            try:
                result = self.generate(prompt, negative_prompt, **kwargs)
                results.append(result)
            except Exception as e:
                self.logger.error(f"生成第{i+1}张图片失败: {e}")
                results.append({"error": str(e), "prompt": prompt})

        return results