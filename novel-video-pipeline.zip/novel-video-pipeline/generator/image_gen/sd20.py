"""
Stable Diffusion 2.0 图片生成适配器
支持SD2.0及相关兼容API（如Run diffusion、CogView等）
"""
import logging
import time
import requests
from typing import List, Dict, Any, Optional

from generator.image_gen.base import BaseImageGenerator

logger = logging.getLogger(__name__)


class SD20ImageGenerator(BaseImageGenerator):
    """
    Stable Diffusion 2.0 图片生成器

    支持SD2.0及兼容的API服务
    默认使用stability.ai官方API或兼容服务
    """

    def __init__(
        self,
        api_key: str,
        model: str = "sd-2.1",
        base_url: str = "https://api.stability.ai/v1",
        timeout: int = 120,
        max_retries: int = 3
    ):
        """
        初始化SD2.0图片生成器

        Args:
            api_key: Stability AI API密钥
            model: 模型名称，如"sd-2.1", "sd-xl"
            base_url: API基础URL
            timeout: 请求超时
            max_retries: 最大重试次数
        """
        super().__init__(api_key, model, timeout, max_retries)
        self.base_url = base_url.rstrip('/')

        self.default_params = {
            "model": self.model,
            "size": "1024x1024",
            "steps": 30,
            "cfg_scale": 7.5,
            "negative_prompt": "no realistic, no photo, no photograph, realistic, photograph, photo, 写实, 真人照片, low quality, blurry"
        }

    def get_model_name(self) -> str:
        return f"sd20-{self.model}"

    def generate(
        self,
        prompt: str,
        negative_prompt: Optional[str] = None,
        size: str = "1024x1024",
        steps: int = 30,
        cfg_scale: float = 7.5,
        **kwargs
    ) -> Dict[str, Any]:
        """
        生成单张图片

        Args:
            prompt: 正向提示词
            negative_prompt: 负向提示词
            size: 图片尺寸
            steps: 生成步数
            cfg_scale: CFG量表
            **kwargs: 其他参数

        Returns:
            Dict: {
                "image_url": str,
                "image_base64": str,  # Base64编码图片
                "seed": int,
                "data": dict
            }
        """
        self._init_session()

        try:
            # 解析尺寸
            width, height = map(int, size.split('x'))

            # 构建请求参数
            payload = {
                "text_prompts": [
                    {"text": prompt, "weight": 1}
                ],
                "cfg_scale": cfg_scale,
                "height": height,
                "width": width,
                "steps": steps,
                "samples": 1
            }

            # 添加负向提示词
            neg_prompt = negative_prompt or self.default_params["negative_prompt"]
            if neg_prompt:
                payload["text_prompts"].append({
                    "text": neg_prompt,
                    "weight": -1
                })

            url = f"{self.base_url}/generation/{self.model}/text-to-image"
            self.logger.info(f"调用SD2.0 API生成图片: {prompt[:50]}...")

            response = self.session.post(
                url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()

            data = response.json()
            self.logger.info(f"SD2.0 API响应成功")

            # 解析响应
            artifacts = data.get("artifacts", [])
            if artifacts:
                artifact = artifacts[0]
                result = {
                    "image_base64": artifact.get("base64"),
                    "seed": artifact.get("seed"),
                    "finish_reason": artifact.get("finishReason"),
                    "data": data
                }
                return result
            else:
                raise Exception("API响应中未找到图片")

        except requests.Timeout:
            self.logger.error("请求超时")
            raise
        except requests.RequestException as e:
            self.logger.error(f"请求失败: {e}")
            raise
        finally:
            self._cleanup_session()

    def generate_batch(
        self,
        prompts: List[str],
        negative_prompt: Optional[str] = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        批量生成图片

        Args:
            prompts: 提示词列表
            negative_prompt: 负向提示词
            **kwargs: 其他参数

        Returns:
            图片列表
        """
        results = []
        for i, prompt in enumerate(prompts):
            self.logger.info(f"批量生成图片 [{i+1}/{len(prompts)}]")
            try:
                result = self.generate(prompt, negative_prompt, **kwargs)
                results.append(result)
            except Exception as e:
                self.logger.error(f"生成第{i+1}张图片失败: {e}")
                results.append({"error": str(e), "prompt": prompt})

        return results