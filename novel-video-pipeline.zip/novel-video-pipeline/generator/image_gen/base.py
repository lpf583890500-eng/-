"""
图片生成器基类
定义所有图片生成适配器的统一接口
"""
import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class BaseImageGenerator(ABC):
    """
    图片生成器抽象基类

    所有图片生成平台适配器都必须继承此类
    并实现其中的抽象方法
    """

    def __init__(
        self,
        api_key: str,
        model: str = "default",
        timeout: int = 120,
        max_retries: int = 3
    ):
        """
        初始化图片生成器

        Args:
            api_key: API密钥
            model: 模型名称，默认使用平台推荐模型
            timeout: 请求超时时间（秒）
            max_retries: 最大重试次数
        """
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = logging.getLogger(self.__class__.__name__)

        # 子类应初始化自己的session
        self.session = None

    @abstractmethod
    def generate(
        self,
        prompt: str,
        negative_prompt: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        生成单张图片

        Args:
            prompt: 正向提示词
            negative_prompt: 负向提示词
            **kwargs: 平台特定参数

        Returns:
            Dict包含:
                - image_url: 图片URL（如果有）
                - image_path: 本地图片路径（如果有）
                - data: 原始响应数据
        """
        pass

    @abstractmethod
    def generate_batch(
        self,
        prompts: List[str],
        negative_prompt: Optional[str] = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        批量生成图片

        Args:
            prompts: 提示词列表
            negative_prompt: 负向提示词
            **kwargs: 平台特定参数

        Returns:
            图片列表
        """
        pass

    @abstractmethod
    def get_model_name(self) -> str:
        """
        获取当前使用的模型名称

        Returns:
            模型名称字符串
        """
        pass

    def _init_session(self):
        """初始化HTTP会话（可选，子类可覆盖）"""
        import requests
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}"
        })

    def _cleanup_session(self):
        """清理HTTP会话"""
        if self.session:
            self.session.close()
            self.session = None

    def __enter__(self):
        self._init_session()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._cleanup_session()
        return False