"""
图片生成模块测试用例
测试图片生成适配器的核心功能
"""
import pytest
from unittest.mock import MagicMock, patch
import os


class TestImageGenBase:
    """图片生成适配器基类测试"""

    def test_base_class_has_required_methods(self):
        """测试基类定义了所有必需方法"""
        from generator.image_gen.base import BaseImageGenerator

        assert hasattr(BaseImageGenerator, 'generate')
        assert hasattr(BaseImageGenerator, 'generate_batch')
        assert hasattr(BaseImageGenerator, 'get_model_name')

    def test_base_generate_signature(self):
        """测试generate方法签名"""
        from generator.image_gen.base import BaseImageGenerator
        import inspect

        sig = inspect.signature(BaseImageGenerator.generate)
        params = list(sig.parameters.keys())

        assert 'prompt' in params

    def test_base_generate_batch_signature(self):
        """测试generate_batch方法签名"""
        from generator.image_gen.base import BaseImageGenerator
        import inspect

        sig = inspect.signature(BaseImageGenerator.generate_batch)
        params = list(sig.parameters.keys())

        assert 'prompts' in params


class TestJimengImageGen:
    """即梦图片生成器测试"""

    def test_jimeng_adapter_instantiation(self):
        """测试即梦适配器可以实例化"""
        from generator.image_gen.jimeng import JimengImageGenerator

        adapter = JimengImageGenerator(api_key="test-key", model="jimeng-2.0")
        assert adapter.model == "jimeng-2.0"
        assert adapter.api_key == "test-key"

    def test_jimeng_get_model_name(self):
        """测试获取模型名称"""
        from generator.image_gen.jimeng import JimengImageGenerator

        adapter = JimengImageGenerator(api_key="test-key")
        assert "jimeng" in adapter.get_model_name().lower()

    def test_jimeng_default_params(self):
        """测试默认参数设置"""
        from generator.image_gen.jimeng import JimengImageGenerator

        adapter = JimengImageGenerator(api_key="test-key")
        assert adapter.default_params["model"] == "jimeng-2.0"
        assert "size" in adapter.default_params
        assert "steps" in adapter.default_params


class TestSD20ImageGen:
    """SD2.0图片生成器测试"""

    def test_sd20_adapter_instantiation(self):
        """测试SD2.0适配器可以实例化"""
        from generator.image_gen.sd20 import SD20ImageGenerator

        adapter = SD20ImageGenerator(api_key="test-key", model="sd-2.1")
        assert adapter.model == "sd-2.1"
        assert adapter.api_key == "test-key"

    def test_sd20_get_model_name(self):
        """测试获取模型名称"""
        from generator.image_gen.sd20 import SD20ImageGenerator

        adapter = SD20ImageGenerator(api_key="test-key")
        assert "sd20" in adapter.get_model_name().lower() or "stable" in adapter.get_model_name().lower()

    def test_sd20_negative_prompt_default(self):
        """测试SD2.0负向提示词默认值"""
        from generator.image_gen.sd20 import SD20ImageGenerator

        adapter = SD20ImageGenerator(api_key="test-key")
        default_neg = adapter.default_params.get("negative_prompt", "")
        assert "realistic" in default_neg or "photo" in default_neg


class TestWanImageGen:
    """Wan图片生成器测试"""

    def test_wan_adapter_instantiation(self):
        """测试Wan适配器可以实例化"""
        from generator.image_gen.wan import WanImageGenerator

        adapter = WanImageGenerator(api_key="test-key", model="wan-2.1")
        assert adapter.model == "wan-2.1"
        assert adapter.api_key == "test-key"

    def test_wan_get_model_name(self):
        """测试获取模型名称"""
        from generator.image_gen.wan import WanImageGenerator

        adapter = WanImageGenerator(api_key="test-key")
        assert "wan" in adapter.get_model_name().lower()


class TestImageGenFactory:
    """图片生成工厂类测试"""

    def test_factory_create_jimeng(self):
        """测试工厂创建即梦实例"""
        from generator.image_gen.factory import ImageGenFactory

        adapter = ImageGenFactory.create("jimeng", api_key="test-key")
        assert adapter is not None
        assert hasattr(adapter, 'generate')

    def test_factory_create_sd20(self):
        """测试工厂创建SD2.0实例"""
        from generator.image_gen.factory import ImageGenFactory

        adapter = ImageGenFactory.create("sd20", api_key="test-key")
        assert adapter is not None

    def test_factory_create_wan(self):
        """测试工厂创建Wan实例"""
        from generator.image_gen.factory import ImageGenFactory

        adapter = ImageGenFactory.create("wan", api_key="test-key")
        assert adapter is not None

    def test_factory_unsupported_type(self):
        """测试工厂处理不支持的类型"""
        from generator.image_gen.factory import ImageGenFactory

        with pytest.raises(ValueError):
            ImageGenFactory.create("unsupported", api_key="test-key")

    def test_factory_list_supported(self):
        """测试列出支持的平台"""
        from generator.image_gen.factory import ImageGenFactory

        supported = ImageGenFactory.list_supported()
        assert isinstance(supported, list)
        assert len(supported) >= 3


class TestImageGenIntegration:
    """图片生成集成测试"""

    def test_adapter_supports_base_methods(self):
        """测试各适配器都支持基类方法"""
        from generator.image_gen.jimeng import JimengImageGenerator
        from generator.image_gen.sd20 import SD20ImageGenerator
        from generator.image_gen.wan import WanImageGenerator

        adapters = [
            JimengImageGenerator(api_key="test"),
            SD20ImageGenerator(api_key="test"),
            WanImageGenerator(api_key="test")
        ]

        for adapter in adapters:
            assert hasattr(adapter, 'generate')
            assert hasattr(adapter, 'generate_batch')
            assert hasattr(adapter, 'get_model_name')

    def test_negative_prompt_parameter(self):
        """测试负向提示词参数"""
        from generator.image_gen.jimeng import JimengImageGenerator

        adapter = JimengImageGenerator(api_key="test")
        import inspect
        sig = inspect.signature(adapter.generate)
        params = list(sig.parameters.keys())
        assert 'negative_prompt' in params or 'kwargs' in params


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
