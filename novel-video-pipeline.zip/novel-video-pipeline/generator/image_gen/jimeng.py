"""
即梦AI图片生成适配器
火山引擎即梦AI（JiMeng AI）文生图接口
"""
import logging
import time
import requests
from typing import List, Dict, Any, Optional

from generator.image_gen.base import BaseImageGenerator

logger = logging.getLogger(__name__)


class JimengImageGenerator(BaseImageGenerator):
    """
    即梦AI图片生成器

    支持即梦AI的文生图功能
    文档: https://www.volcengine.com/docs/jimeng
    """

    BASE_URL = "https://www.volcengine.com/api/jimeng/v1"

    def __init__(
        self,
        api_key: str,
        model: str = "jimeng-2.0",
        timeout: int = 120,
        max_retries: int = 3
    ):
        """
        初始化即梦图片生成器

        Args:
            api_key: 火山引擎API密钥
            model: 模型名称
            timeout: 请求超时
            max_retries: 最大重试次数
        """
        super().__init__(api_key, model, timeout, max_retries)

        self.default_params = {
            "model": self.model,
            "size": "1024x1024",
            "steps": 20,
            "style": "3d",
            "quality": "standard"
        }

    def get_model_name(self) -> str:
        return f"jimeng-{self.model}"

    def generate(
        self,
        prompt: str,
        negative_prompt: Optional[str] = None,
        size: str = "1024x1024",
        style: str = "3d",
        **kwargs
    ) -> Dict[str, Any]:
        """
        生成单张图片

        Args:
            prompt: 正向提示词
            negative_prompt: 负向提示词
            size: 图片尺寸，如"1024x1024"
            style: 风格，如"3d", "anime", "realistic"
            **kwargs: 其他参数

        Returns:
            Dict: {
                "image_url": str,  # 生成的图片URL
                "image_path": str, # 本地保存路径
                "task_id": str,    # 任务ID
                "data": dict       # 原始响应
            }
        """
        self._init_session()

        try:
            # 构建请求参数
            payload = {
                "model": self.model,
                "prompt": prompt,
                "negative_prompt": negative_prompt or "no realistic, no photo, no photograph, 禁止写实, 禁止真人照片",
                "size": size,
                "style": style,
                **kwargs
            }

            # 调用即梦API
            url = f"{self.BASE_URL}/image/generate"
            self.logger.info(f"调用即梦API生成图片: {prompt[:50]}...")

            response = self.session.post(
                url,
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()

            data = response.json()
            self.logger.info(f"即梦API响应: {data}")

            # 解析响应
            if data.get("code") == 0 or data.get("status") == "success":
                result = {
                    "image_url": data.get("data", {}).get("image_url"),
                    "task_id": data.get("task_id"),
                    "data": data
                }
                return result
            else:
                raise Exception(f"API错误: {data.get('message', 'Unknown error')}")

        except requests.Timeout:
            self.logger.error("请求超时")
            raise
        except requests.RequestException as e:
            self.logger.error(f"请求失败: {e}")
            raise
        finally:
            self._cleanup_session()

    def generate_batch(
        self,
        prompts: List[str],
        negative_prompt: Optional[str] = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        批量生成图片

        Args:
            prompts: 提示词列表
            negative_prompt: 负向提示词
            **kwargs: 其他参数

        Returns:
            图片列表
        """
        results = []
        for i, prompt in enumerate(prompts):
            self.logger.info(f"批量生成图片 [{i+1}/{len(prompts)}]")
            try:
                result = self.generate(prompt, negative_prompt, **kwargs)
                results.append(result)
            except Exception as e:
                self.logger.error(f"生成第{i+1}张图片失败: {e}")
                results.append({"error": str(e), "prompt": prompt})

        return results