"""
图片生成模块
支持多种图片生成平台：即梦、SD2.0、Wan等
"""

from generator.image_gen.base import BaseImageGenerator
from generator.image_gen.jimeng import JimengImageGenerator
from generator.image_gen.sd20 import SD20ImageGenerator
from generator.image_gen.wan import WanImageGenerator
from generator.image_gen.factory import ImageGenFactory

__all__ = [
    'BaseImageGenerator',
    'JimengImageGenerator',
    'SD20ImageGenerator',
    'WanImageGenerator',
    'ImageGenFactory'
]