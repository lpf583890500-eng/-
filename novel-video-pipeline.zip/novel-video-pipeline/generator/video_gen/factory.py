"""
视频生成工厂类
统一创建视频生成适配器实例
"""
import logging
from typing import Any

logger = logging.getLogger(__name__)


class VideoGenFactory:
    """
    视频生成器工厂类

    提供统一的接口创建不同平台的视频生成器
    """

    # 支持的平台映射
    _PLATFORMS = {
        "kling": "generator.video_gen.kling.KlingVideoGenerator",
        "klingai": "generator.video_gen.kling.KlingVideoGenerator",
        "jimeng_video": "generator.video_gen.jimeng.JimengVideoGenerator",
        "jimeng": "generator.video_gen.jimeng.JimengVideoGenerator",
        "pixverse": "generator.video_gen.pixverse.PixverseVideoGenerator",
        "pixverse_ai": "generator.video_gen.pixverse.PixverseVideoGenerator",
    }

    @classmethod
    def create(
        cls,
        platform: str,
        api_key: str,
        **kwargs
    ) -> Any:
        """
        创建视频生成器实例

        Args:
            platform: 平台名称
            api_key: API密钥
            **kwargs: 其他参数

        Returns:
            对应平台的视频生成器实例

        Raises:
            ValueError: 不支持的平台
        """
        platform_lower = platform.lower()

        if platform_lower not in cls._PLATFORMS:
            supported = list(set(cls._PLATFORMS.keys()))
            raise ValueError(
                f"不支持的视频生成平台: {platform}\n"
                f"支持的平台: {', '.join(supported)}"
            )

        # 动态导入
        import importlib
        module_path = cls._PLATFORMS[platform_lower]
        module_name, class_name = module_path.rsplit('.', 1)
        module = importlib.import_module(module_name)
        generator_class = getattr(module, class_name)

        logger.info(f"创建视频生成器: {platform}")
        return generator_class(api_key=api_key, **kwargs)

    @classmethod
    def list_supported(cls) -> list:
        """
        列出所有支持的平台

        Returns:
            平台名称列表
        """
        return list(set(cls._PLATFORMS.keys()))

    @classmethod
    def register(cls, name: str, module_path: str):
        """
        注册新的视频生成平台（扩展用）

        Args:
            name: 平台名称
            module_path: 模块路径
        """
        cls._PLATFORMS[name.lower()] = module_path
        logger.info(f"已注册新视频生成平台: {name}")