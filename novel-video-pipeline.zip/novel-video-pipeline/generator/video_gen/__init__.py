"""
视频生成模块
支持多种视频生成平台：可灵、即梦、PixVerse等
"""

from generator.video_gen.base import BaseVideoGenerator
from generator.video_gen.kling import KlingVideoGenerator
from generator.video_gen.jimeng import JimengVideoGenerator
from generator.video_gen.pixverse import PixverseVideoGenerator
from generator.video_gen.factory import VideoGenFactory


def create_video_gen_provider(provider: str, **kwargs) -> BaseVideoGenerator:
    """便捷工厂函数：通过 provider name 创建视频生成器实例"""
    return VideoGenFactory.create(provider, **kwargs)


__all__ = [
    'BaseVideoGenerator',
    'KlingVideoGenerator',
    'JimengVideoGenerator',
    'PixverseVideoGenerator',
    'VideoGenFactory',
    'create_video_gen_provider',
]