"""
可灵AI视频生成适配器
快手可灵AI（Kling AI）文生视频/图生视频接口
"""
import logging
import time
import requests
from typing import Dict, Any, Optional

from generator.video_gen.base import BaseVideoGenerator

logger = logging.getLogger(__name__)


class KlingVideoGenerator(BaseVideoGenerator):
    """
    可灵AI视频生成器

    支持可灵AI的文生视频和图生视频功能
    文档: https://www.klingai.com/docs
    """

    BASE_URL = "https://api.klingai.com/v1"

    def __init__(
        self,
        api_key: str,
        model: str = "kling-v1",
        timeout: int = 300,
        max_retries: int = 3
    ):
        """
        初始化可灵视频生成器

        Args:
            api_key: 可灵AI API密钥
            model: 模型名称
            timeout: 请求超时
            max_retries: 最大重试次数
        """
        super().__init__(api_key, model, timeout, max_retries)

        self.default_params = {
            "model": self.model,
            "duration": 5,
            "aspect_ratio": "16:9",
            "quality": "standard"
        }

    def get_model_name(self) -> str:
        return f"kling-{self.model}"

    def generate(
        self,
        prompt: str,
        duration: int = 5,
        aspect_ratio: str = "16:9",
        **kwargs
    ) -> Dict[str, Any]:
        """
        文生视频

        Args:
            prompt: 正向提示词
            duration: 视频时长（秒），支持5/10秒
            aspect_ratio: 宽高比
            **kwargs: 其他参数

        Returns:
            Dict: {
                "video_url": str,
                "video_path": str,
                "task_id": str,
                "data": dict
            }
        """
        self._init_session()

        try:
            # 构建请求参数
            payload = {
                "model": self.model,
                "prompt": prompt,
                "duration": duration,
                "aspect_ratio": aspect_ratio,
                "mode": "high_quality",
                **kwargs
            }

            # 提交任务
            url = f"{self.BASE_URL}/video/generation"
            self.logger.info(f"提交可灵视频生成任务: {prompt[:50]}...")

            response = self.session.post(
                url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()

            data = response.json()
            self.logger.info(f"可灵API响应: {data}")

            task_id = data.get("task_id")
            if not task_id:
                raise Exception(f"未获取到task_id: {data}")

            # 轮询等待结果
            video_url = self._wait_for_completion(task_id)

            result = {
                "video_url": video_url,
                "task_id": task_id,
                "data": data
            }
            return result

        except requests.Timeout:
            self.logger.error("请求超时")
            raise
        except requests.RequestException as e:
            self.logger.error(f"请求失败: {e}")
            raise
        finally:
            self._cleanup_session()

    def generate_from_image(
        self,
        image_path: str,
        prompt: str,
        duration: int = 5,
        **kwargs
    ) -> Dict[str, Any]:
        """
        图生视频

        Args:
            image_path: 输入图片路径
            prompt: 提示词
            duration: 视频时长（秒）
            **kwargs: 其他参数

        Returns:
            Dict: {
                "video_url": str,
                "video_path": str,
                "task_id": str,
                "data": dict
            }
        """
        self._init_session()

        try:
            # 读取图片并转为base64
            import base64
            with open(image_path, 'rb') as f:
                image_base64 = base64.b64encode(f.read()).decode()

            # 构建请求参数
            payload = {
                "model": self.model,
                "image": f"data:image/png;base64,{image_base64}",
                "prompt": prompt,
                "duration": duration,
                "mode": "high_quality",
                **kwargs
            }

            # 提交任务
            url = f"{self.BASE_URL}/video/generation/image-to-video"
            self.logger.info(f"提交可灵图生视频任务: {image_path}")

            response = self.session.post(
                url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()

            data = response.json()
            task_id = data.get("task_id")
            if not task_id:
                raise Exception(f"未获取到task_id: {data}")

            # 轮询等待结果
            video_url = self._wait_for_completion(task_id)

            result = {
                "video_url": video_url,
                "task_id": task_id,
                "data": data
            }
            return result

        except requests.Timeout:
            self.logger.error("请求超时")
            raise
        except requests.RequestException as e:
            self.logger.error(f"请求失败: {e}")
            raise
        finally:
            self._cleanup_session()

    def _wait_for_completion(self, task_id: str, poll_interval: int = 5) -> str:
        """
        轮询等待任务完成

        Args:
            task_id: 任务ID
            poll_interval: 轮询间隔（秒）

        Returns:
            生成的视频URL
        """
        url = f"{self.BASE_URL}/video/generation/{task_id}"

        for attempt in range(self.max_retries * 10):  # 最多等待50次
            self.logger.info(f"轮询任务状态 [{attempt + 1}]: {task_id}")

            response = self.session.get(url, timeout=30)
            response.raise_for_status()

            data = response.json()
            status = data.get("status")

            if status == "completed":
                return data.get("video_url")
            elif status == "failed":
                raise Exception(f"任务失败: {data.get('error', 'Unknown')}")
            else:
                # 等待后继续轮询
                time.sleep(poll_interval)

        raise Exception(f"等待超时，任务ID: {task_id}")