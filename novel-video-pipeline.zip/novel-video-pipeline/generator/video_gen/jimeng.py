"""
即梦AI视频生成适配器
火山引擎即梦AI（JiMeng AI）图生视频接口
"""
import logging
import time
import requests
from typing import Dict, Any

from generator.video_gen.base import BaseVideoGenerator

logger = logging.getLogger(__name__)


class JimengVideoGenerator(BaseVideoGenerator):
    """
    即梦AI视频生成器

    支持即梦AI的图生视频功能
    文档: https://www.volcengine.com/docs/jimeng
    """

    BASE_URL = "https://www.volcengine.com/api/jimeng/v1"

    def __init__(
        self,
        api_key: str,
        model: str = "jimeng-video-v1",
        timeout: int = 300,
        max_retries: int = 3
    ):
        """
        初始化即梦视频生成器

        Args:
            api_key: 火山引擎API密钥
            model: 模型名称
            timeout: 请求超时
            max_retries: 最大重试次数
        """
        super().__init__(api_key, model, timeout, max_retries)

        self.default_params = {
            "model": self.model,
            "duration": 5,
            "aspect_ratio": "16:9"
        }

    def get_model_name(self) -> str:
        return f"jimeng-video-{self.model}"

    def generate(
        self,
        prompt: str,
        duration: int = 5,
        aspect_ratio: str = "16:9",
        **kwargs
    ) -> Dict[str, Any]:
        """
        即梦主要支持图生视频，文生视频使用generate_from_image
        此方法会尝试调用，若不支持则抛出明确错误

        Args:
            prompt: 提示词
            duration: 视频时长
            aspect_ratio: 宽高比
            **kwargs: 其他参数

        Returns:
            Dict: {
                "video_url": str,
                "video_path": str,
                "task_id": str,
                "data": dict
            }
        """
        # 即梦主要支持图生视频，文生视频需要先生成图片
        raise NotImplementedError(
            "即梦AI主要支持图生视频，请使用generate_from_image方法，"
            "或先使用JimengImageGenerator生成图片"
        )

    def generate_from_image(
        self,
        image_path: str,
        prompt: str,
        duration: int = 5,
        **kwargs
    ) -> Dict[str, Any]:
        """
        图生视频

        Args:
            image_path: 输入图片路径
            prompt: 提示词
            duration: 视频时长（秒）
            **kwargs: 其他参数

        Returns:
            Dict: {
                "video_url": str,
                "video_path": str,
                "task_id": str,
                "data": dict
            }
        """
        self._init_session()

        try:
            # 读取图片
            import base64
            with open(image_path, 'rb') as f:
                image_base64 = base64.b64encode(f.read()).decode()

            # 构建请求参数
            payload = {
                "model": self.model,
                "image": f"data:image/png;base64,{image_base64}",
                "prompt": prompt,
                "duration": duration,
                **kwargs
            }

            # 提交任务
            url = f"{self.BASE_URL}/video/generation/image-to-video"
            self.logger.info(f"提交即梦图生视频任务: {image_path}")

            response = self.session.post(
                url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()

            data = response.json()
            self.logger.info(f"即梦API响应: {data}")

            task_id = data.get("task_id")
            if not task_id:
                raise Exception(f"未获取到task_id: {data}")

            # 轮询等待结果
            video_url = self._wait_for_completion(task_id)

            result = {
                "video_url": video_url,
                "task_id": task_id,
                "data": data
            }
            return result

        except requests.Timeout:
            self.logger.error("请求超时")
            raise
        except requests.RequestException as e:
            self.logger.error(f"请求失败: {e}")
            raise
        finally:
            self._cleanup_session()

    def _wait_for_completion(self, task_id: str, poll_interval: int = 5) -> str:
        """
        轮询等待任务完成

        Args:
            task_id: 任务ID
            poll_interval: 轮询间隔（秒）

        Returns:
            生成的视频URL
        """
        url = f"{self.BASE_URL}/video/generation/{task_id}"

        for attempt in range(self.max_retries * 10):
            self.logger.info(f"轮询任务状态 [{attempt + 1}]: {task_id}")

            response = self.session.get(url, timeout=30)
            response.raise_for_status()

            data = response.json()
            status = data.get("status")

            if status == "completed":
                return data.get("video_url")
            elif status == "failed":
                raise Exception(f"任务失败: {data.get('error', 'Unknown')}")
            else:
                time.sleep(poll_interval)

        raise Exception(f"等待超时，任务ID: {task_id}")