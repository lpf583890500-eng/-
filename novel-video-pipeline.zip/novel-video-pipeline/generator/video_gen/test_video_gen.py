"""
视频生成模块测试用例
测试视频生成适配器的核心功能
"""
import pytest
from unittest.mock import MagicMock, patch
import os


class TestVideoGenBase:
    """视频生成适配器基类测试"""

    def test_base_class_has_required_methods(self):
        """测试基类定义了所有必需方法"""
        from generator.video_gen.base import BaseVideoGenerator

        assert hasattr(BaseVideoGenerator, 'generate')
        assert hasattr(BaseVideoGenerator, 'generate_from_image')
        assert hasattr(BaseVideoGenerator, 'get_model_name')

    def test_base_generate_signature(self):
        """测试generate方法签名"""
        from generator.video_gen.base import BaseVideoGenerator
        import inspect

        sig = inspect.signature(BaseVideoGenerator.generate)
        params = list(sig.parameters.keys())

        assert 'prompt' in params
        assert 'duration' in params or 'seconds' in params or params == ['self', 'prompt']

    def test_base_generate_from_image_signature(self):
        """测试generate_from_image方法签名"""
        from generator.video_gen.base import BaseVideoGenerator
        import inspect

        sig = inspect.signature(BaseVideoGenerator.generate_from_image)
        params = list(sig.parameters.keys())

        assert 'image_path' in params
        assert 'prompt' in params


class TestKlingVideoGen:
    """可灵视频生成器测试"""

    def test_kling_adapter_instantiation(self):
        """测试可灵适配器可以实例化"""
        from generator.video_gen.kling import KlingVideoGenerator

        adapter = KlingVideoGenerator(api_key="test-key")
        assert adapter.api_key == "test-key"

    def test_kling_get_model_name(self):
        """测试获取模型名称"""
        from generator.video_gen.kling import KlingVideoGenerator

        adapter = KlingVideoGenerator(api_key="test-key")
        assert "kling" in adapter.get_model_name().lower() or "klingai" in adapter.get_model_name().lower()

    def test_kling_default_params(self):
        """测试默认参数设置"""
        from generator.video_gen.kling import KlingVideoGenerator

        adapter = KlingVideoGenerator(api_key="test-key")
        assert "model" in adapter.default_params
        assert "duration" in adapter.default_params


class TestJimengVideoGen:
    """即梦视频生成器测试"""

    def test_jimeng_video_adapter_instantiation(self):
        """测试即梦视频适配器可以实例化"""
        from generator.video_gen.jimeng import JimengVideoGenerator

        adapter = JimengVideoGenerator(api_key="test-key")
        assert adapter.api_key == "test-key"

    def test_jimeng_video_get_model_name(self):
        """测试获取模型名称"""
        from generator.video_gen.jimeng import JimengVideoGenerator

        adapter = JimengVideoGenerator(api_key="test-key")
        assert "jimeng" in adapter.get_model_name().lower()


class TestPixverseVideoGen:
    """PixVerse视频生成器测试"""

    def test_pixverse_adapter_instantiation(self):
        """测试PixVerse适配器可以实例化"""
        from generator.video_gen.pixverse import PixverseVideoGenerator

        adapter = PixverseVideoGenerator(api_key="test-key")
        assert adapter.api_key == "test-key"

    def test_pixverse_get_model_name(self):
        """测试获取模型名称"""
        from generator.video_gen.pixverse import PixverseVideoGenerator

        adapter = PixverseVideoGenerator(api_key="test-key")
        assert "pixverse" in adapter.get_model_name().lower()


class TestVideoGenFactory:
    """视频生成工厂类测试"""

    def test_factory_create_kling(self):
        """测试工厂创建可灵实例"""
        from generator.video_gen.factory import VideoGenFactory

        adapter = VideoGenFactory.create("kling", api_key="test-key")
        assert adapter is not None
        assert hasattr(adapter, 'generate')

    def test_factory_create_jimeng(self):
        """测试工厂创建即梦视频实例"""
        from generator.video_gen.factory import VideoGenFactory

        adapter = VideoGenFactory.create("jimeng_video", api_key="test-key")
        assert adapter is not None

    def test_factory_create_pixverse(self):
        """测试工厂创建PixVerse实例"""
        from generator.video_gen.factory import VideoGenFactory

        adapter = VideoGenFactory.create("pixverse", api_key="test-key")
        assert adapter is not None

    def test_factory_unsupported_type(self):
        """测试工厂处理不支持的类型"""
        from generator.video_gen.factory import VideoGenFactory

        with pytest.raises(ValueError):
            VideoGenFactory.create("unsupported", api_key="test-key")

    def test_factory_list_supported(self):
        """测试列出支持的平台"""
        from generator.video_gen.factory import VideoGenFactory

        supported = VideoGenFactory.list_supported()
        assert isinstance(supported, list)
        assert len(supported) >= 3


class TestVideoGenIntegration:
    """视频生成集成测试"""

    def test_all_adapters_support_base_methods(self):
        """测试各适配器都支持基类方法"""
        from generator.video_gen.kling import KlingVideoGenerator
        from generator.video_gen.jimeng import JimengVideoGenerator
        from generator.video_gen.pixverse import PixverseVideoGenerator

        adapters = [
            KlingVideoGenerator(api_key="test"),
            JimengVideoGenerator(api_key="test"),
            PixverseVideoGenerator(api_key="test")
        ]

        for adapter in adapters:
            assert hasattr(adapter, 'generate')
            assert hasattr(adapter, 'generate_from_image')
            assert hasattr(adapter, 'get_model_name')

    def test_duration_parameter(self):
        """测试时长参数"""
        from generator.video_gen.kling import KlingVideoGenerator

        adapter = KlingVideoGenerator(api_key="test")
        import inspect
        sig = inspect.signature(adapter.generate)
        params = list(sig.parameters.keys())
        assert 'duration' in params or 'kwargs' in params

    def test_aspect_ratio_parameter(self):
        """测试宽高比参数"""
        from generator.video_gen.kling import KlingVideoGenerator

        adapter = KlingVideoGenerator(api_key="test")
        import inspect
        sig = inspect.signature(adapter.generate)
        params = list(sig.parameters.keys())
        assert 'aspect_ratio' in params or 'kwargs' in params


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
