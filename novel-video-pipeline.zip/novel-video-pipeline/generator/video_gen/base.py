"""
视频生成器基类
定义所有视频生成适配器的统一接口
"""
import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class BaseVideoGenerator(ABC):
    """
    视频生成器抽象基类

    所有视频生成平台适配器都必须继承此类
    并实现其中的抽象方法
    """

    def __init__(
        self,
        api_key: str,
        model: str = "default",
        timeout: int = 300,
        max_retries: int = 3,
        api_secret: str | None = None,
    ):
        """
        初始化视频生成器

        Args:
            api_key: API密钥
            model: 模型名称
            timeout: 请求超时时间（秒），视频生成通常需要更长时间
            max_retries: 最大重试次数
            api_secret: API密钥secret（如火山引擎等需要）
        """
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.api_secret = api_secret
        self.logger = logging.getLogger(self.__class__.__name__)

        # 子类应初始化自己的session
        self.session = None

    @abstractmethod
    def generate(
        self,
        prompt: str,
        duration: int = 5,
        aspect_ratio: str = "16:9",
        **kwargs
    ) -> Dict[str, Any]:
        """
        文生视频

        Args:
            prompt: 正向提示词
            duration: 视频时长（秒）
            aspect_ratio: 宽高比，如"16:9", "9:16"
            **kwargs: 平台特定参数

        Returns:
            Dict包含:
                - video_url: 视频URL
                - video_path: 本地视频路径
                - task_id: 任务ID
                - data: 原始响应
        """
        pass

    @abstractmethod
    def generate_from_image(
        self,
        image_path: str,
        prompt: str,
        duration: int = 5,
        **kwargs
    ) -> Dict[str, Any]:
        """
        图生视频

        Args:
            image_path: 输入图片路径
            prompt: 提示词
            duration: 视频时长（秒）
            **kwargs: 平台特定参数

        Returns:
            Dict包含:
                - video_url: 视频URL
                - video_path: 本地视频路径
                - task_id: 任务ID
                - data: 原始响应
        """
        pass

    @abstractmethod
    def get_model_name(self) -> str:
        """
        获取当前使用的模型名称

        Returns:
            模型名称字符串
        """
        pass

    def _init_session(self):
        """初始化HTTP会话（可选，子类可覆盖）"""
        import requests
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}"
        })

    def _cleanup_session(self):
        """清理HTTP会话"""
        if self.session:
            self.session.close()
            self.session = None

    def __enter__(self):
        self._init_session()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._cleanup_session()
        return False